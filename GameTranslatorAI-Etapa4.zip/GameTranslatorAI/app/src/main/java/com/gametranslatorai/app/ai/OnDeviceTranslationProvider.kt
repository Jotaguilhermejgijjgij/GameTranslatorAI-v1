package com.gametranslatorai.app.ai

import com.gametranslatorai.app.settings.model.TargetLanguage
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Provedor de tradução por IA que roda inteiramente no aparelho, usando o
 * Google ML Kit: identificação de idioma ([LanguageIdentification]) e
 * tradução neural on-device ([Translation]).
 *
 * Não depende de nenhuma chave de API nem de serviço pago: os modelos de
 * idioma são baixados automaticamente pelo próprio ML Kit na primeira vez
 * que um par de idiomas é usado (isso exige conexão com a internet só
 * nesse momento) e reutilizados localmente depois disso, sem custo e sem
 * enviar o texto do usuário para nenhum servidor.
 *
 * Nenhuma tradução é inventada: se o idioma de origem não puder ser
 * identificado com confiança, ou se o modelo não puder ser baixado/usado,
 * o resultado é [TranslationOutcome.Unreliable] ou [TranslationOutcome.Failure] —
 * nunca um texto fictício.
 */
class OnDeviceTranslationProvider : TranslationProvider {

    private val languageIdentifier = LanguageIdentification.getClient()
    private val translators = ConcurrentHashMap<String, Translator>()

    override suspend fun translate(text: String, targetLanguage: TargetLanguage): TranslationOutcome {
        if (text.isBlank()) {
            return TranslationOutcome.Unreliable("Texto vazio.")
        }

        val sourceLanguageTag = try {
            identifyLanguage(text)
        } catch (error: Exception) {
            return TranslationOutcome.Failure(error.message ?: "Falha ao identificar o idioma de origem.")
        }

        if (sourceLanguageTag == null || sourceLanguageTag == UNDETERMINED_LANGUAGE_TAG) {
            return TranslationOutcome.Unreliable("Idioma de origem não identificado com confiança.")
        }

        val sourceModelCode = TranslateLanguage.fromLanguageTag(sourceLanguageTag)
            ?: return TranslationOutcome.Unreliable("Idioma de origem não suportado pelo tradutor.")

        val targetModelCode = targetLanguage.toMlKitLanguageCode()

        if (sourceModelCode == targetModelCode) {
            return TranslationOutcome.Unreliable("O texto já está no idioma de destino.")
        }

        return try {
            val translator = getOrCreateTranslator(sourceModelCode, targetModelCode)
            ensureModelDownloaded(translator)
            val translatedText = runTranslation(translator, text)
            TranslationOutcome.Success(
                sourceText = text,
                translatedText = translatedText,
                sourceLanguageCode = sourceModelCode,
                targetLanguage = targetLanguage
            )
        } catch (error: Exception) {
            TranslationOutcome.Failure(error.message ?: "Falha ao traduzir o texto.")
        }
    }

    private suspend fun identifyLanguage(text: String): String? =
        suspendCancellableCoroutine { continuation ->
            languageIdentifier.identifyLanguage(text)
                .addOnSuccessListener { languageTag -> continuation.resume(languageTag) }
                .addOnFailureListener { error -> continuation.resumeWithException(error) }
        }

    private fun getOrCreateTranslator(sourceModelCode: String, targetModelCode: String): Translator {
        val key = "$sourceModelCode-$targetModelCode"
        return translators.getOrPut(key) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(sourceModelCode)
                .setTargetLanguage(targetModelCode)
                .build()
            Translation.getClient(options)
        }
    }

    private suspend fun ensureModelDownloaded(translator: Translator) {
        suspendCancellableCoroutine<Unit> { continuation ->
            translator.downloadModelIfNeeded()
                .addOnSuccessListener { continuation.resume(Unit) }
                .addOnFailureListener { error -> continuation.resumeWithException(error) }
        }
    }

    private suspend fun runTranslation(translator: Translator, text: String): String =
        suspendCancellableCoroutine { continuation ->
            translator.translate(text)
                .addOnSuccessListener { translated -> continuation.resume(translated) }
                .addOnFailureListener { error -> continuation.resumeWithException(error) }
        }

    /**
     * Libera os modelos de tradução carregados em memória. Não é chamado
     * automaticamente entre uma sessão e outra do modo de tradução — os
     * modelos ficam "aquecidos" de propósito, para que reiniciar o modo de
     * tradução não exija recarregar tudo de novo (baixa latência).
     */
    fun close() {
        translators.values.forEach { it.close() }
        translators.clear()
        languageIdentifier.close()
    }

    companion object {
        private const val UNDETERMINED_LANGUAGE_TAG = "und"
    }
}

private fun TargetLanguage.toMlKitLanguageCode(): String = when (this) {
    TargetLanguage.PT -> TranslateLanguage.PORTUGUESE
    TargetLanguage.EN -> TranslateLanguage.ENGLISH
    TargetLanguage.ES -> TranslateLanguage.SPANISH
}
