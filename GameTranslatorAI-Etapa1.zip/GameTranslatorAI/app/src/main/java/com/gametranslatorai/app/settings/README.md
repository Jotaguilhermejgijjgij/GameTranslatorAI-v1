# settings

Reservado para a lógica de configurações do usuário (leitura/escrita das
preferências de aparência, idioma, tradução e IA descritas nas telas de
Configurações).

Será implementado na Etapa 3, junto com `persistence/`.
