package com.gametranslatorai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.gametranslatorai.app.ui.navigation.GameTranslatorNavGraph
import com.gametranslatorai.app.ui.theme.GameTranslatorAITheme

/**
 * Activity única do aplicativo (arquitetura single-activity).
 * Toda a navegação entre telas (splash, home, configurações e futuras
 * telas) acontece dentro do grafo de navegação do Compose.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GameTranslatorAITheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GameTranslatorNavGraph()
                }
            }
        }
    }
}
