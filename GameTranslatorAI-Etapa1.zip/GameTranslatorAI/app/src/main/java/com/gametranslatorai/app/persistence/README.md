# persistence

Reservado para a camada de persistência local (preferências do usuário:
cor do tema, idiomas, app selecionado, configurações de tradução, etc.),
usando DataStore do Android Jetpack.

Será implementado na Etapa 3.
