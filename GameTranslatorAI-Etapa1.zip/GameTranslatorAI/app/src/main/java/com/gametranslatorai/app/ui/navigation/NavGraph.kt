package com.gametranslatorai.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gametranslatorai.app.ui.screens.HomeScreen
import com.gametranslatorai.app.ui.screens.SettingsScreen
import com.gametranslatorai.app.ui.screens.SplashScreen

/** Nomes das rotas de navegação, centralizados para evitar strings soltas. */
object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val SETTINGS = "settings"
}

/**
 * Grafo de navegação principal do app.
 *
 * Etapa 1: apenas 3 telas (splash, home e configurações), ambas em forma
 * de estrutura/estado inicial. Novas rotas serão adicionadas conforme
 * as próximas etapas (ex.: seleção de aplicativo/jogo).
 */
@Composable
fun GameTranslatorNavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinished = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(onOpenSettings = { navController.navigate(Routes.SETTINGS) })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
