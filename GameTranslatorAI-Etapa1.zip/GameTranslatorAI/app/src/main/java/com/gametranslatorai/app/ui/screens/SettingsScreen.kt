package com.gametranslatorai.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Tela de configurações.
 *
 * Etapa 1: apenas a estrutura de navegação (barra superior com botão
 * de voltar). As categorias completas (Aparência, Idioma, Tradução,
 * Inteligência Artificial, Aplicativo, Sobre) serão implementadas na
 * Etapa 3, junto com a camada de persistência.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configurações") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Text(
                text = "As categorias de configuração (Aparência, Idioma, " +
                    "Tradução, Inteligência Artificial, Aplicativo e Sobre) " +
                    "serão adicionadas na Etapa 3.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
