# GameTranslatorAI — Etapa 1: Fundação do projeto

Este é o projeto Android real (Kotlin + Jetpack Compose) do GameTranslatorAI,
na sua Etapa 1: a base do app, compilável, com a arquitetura de pastas
preparada para todas as etapas seguintes.

## O que esta etapa entrega

- Projeto Gradle/Kotlin completo (`build.gradle.kts`, `settings.gradle.kts`,
  `app/build.gradle.kts`), pronto para abrir no Android Studio.
- App single-activity com Jetpack Compose e Material 3.
- Tema branco por padrão, com cantos arredondados (Etapa 2 vai ligar isso
  ao sistema de cores escolhível).
- Splash screen simples com o nome do app.
- Navegação real entre 3 telas: Splash → Home → Configurações.
- Ícone do app provisório (geométrico, vetorial) — ver seção "Ícone" abaixo.
- Estrutura de pacotes (pastas) já criada para todos os módulos futuros,
  cada uma com um `README.md` explicando o que vai entrar ali e em qual
  etapa: `settings/`, `translation/`, `ocr/`, `capture/`, `ai/`,
  `persistence/`, `appselection/`, além de `ui/theme/` e `ui/navigation/`
  já implementados.

## O que NÃO está nesta etapa (de propósito)

Nada de tradução, OCR, captura de tela, IA, seleção de app ou persistência
de configurações foi implementado ainda — isso viria nas Etapas 2 a 11.
As telas de Home e Configurações mostram apenas texto explicando o que vem
a seguir, sem nenhum botão "falso".

## Como abrir o projeto

1. Abra a pasta `GameTranslatorAI/` no Android Studio (versão recente,
   compatível com AGP 8.5.x / Gradle 8.7).
2. O Android Studio vai detectar que faltam os arquivos binários do Gradle
   Wrapper (`gradle/wrapper/gradle-wrapper.jar`, `gradlew`, `gradlew.bat`)
   e oferecer para gerá-los automaticamente ao sincronizar. Aceite a
   sincronização.
   - Alternativa manual (se tiver o Gradle instalado localmente):
     rode `gradle wrapper --gradle-version 8.7` dentro da pasta do projeto.
3. Depois da sincronização, rode o app em um emulador ou aparelho físico
   (botão Run ▶) para gerar e instalar o APK de debug.

> Por que o wrapper não veio pronto? O ambiente onde este projeto foi
> gerado não tem acesso à internet para baixar o `gradle-wrapper.jar`
> (arquivo binário). Isso é normal e resolvido automaticamente pelo
> Android Studio na primeira sincronização, ou manualmente como descrito
> acima.

## Ícone do aplicativo

O ícone atual é um placeholder geométrico (vetorial, sem depender de
imagens PNG), só para o app ter um ícone válido e compilar corretamente.
Ele já está preparado nos formatos necessários:

- `res/mipmap-anydpi-v26/ic_launcher.xml` (+ `_round`): ícone adaptativo,
  Android 8.0 (API 26) em diante.
- `res/mipmap/ic_launcher.xml` (+ `_round`): versão simples para Android
  7.0/7.1 (API 24–25).

Na Etapa 11, basta substituir os vetores em `res/drawable/ic_launcher_*.xml`
(ou os arquivos de mipmap) pela arte final do GameTranslatorAI.

## Checklist de transparência (item 16 do pedido original)

1. **O que já funciona de verdade:** navegação entre telas, tema visual
   (cores/tipografia/formas), splash screen, estrutura de projeto Gradle
   compilável.
2. **O que precisa de configuração adicional:** nada nesta etapa além do
   próprio Android Studio/Gradle Wrapper (ver seção acima).
3. **O que precisa de API externa:** nada ainda — a camada de IA/tradução
   (pasta `ai/`) só será implementada na Etapa 8, e vai exigir uma chave de
   API de um provedor de tradução/IA fornecida por você.
4. **O que precisa de permissão especial do Android:** nada ainda —
   captura de tela (`MediaProjection`) e overlay (`SYSTEM_ALERT_WINDOW`)
   serão pedidos explicitamente ao usuário nas Etapas 6 e 9.
5. **O que ainda precisa ser desenvolvido:** tudo o que está listado nas
   Etapas 2 a 12 do planejamento (cores, idiomas, persistência, seleção de
   app, captura de tela, OCR, IA, caixa de tradução, modos automático/
   manual, ícone final, revisão de compilação completa).

## Estrutura de pastas

```
GameTranslatorAI/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/…
        └── java/com/gametranslatorai/app/
            ├── GameTranslatorApp.kt
            ├── MainActivity.kt
            ├── ui/
            │   ├── navigation/NavGraph.kt
            │   ├── screens/ (Splash, Home, Settings)
            │   └── theme/ (Color, Type, Theme)
            ├── settings/        (Etapa 3)
            ├── persistence/     (Etapa 3)
            ├── appselection/    (Etapa 5)
            ├── capture/         (Etapa 6)
            ├── ocr/             (Etapa 7)
            ├── ai/              (Etapa 8)
            └── translation/     (Etapa 10)
```
