# translation

Reservado para o motor de tradução: orquestra OCR -> texto -> tradução,
nos modos automático e manual.

Será implementado na Etapa 10, após `ocr/` (Etapa 7) e `ai/` (Etapa 8)
estarem prontos.
