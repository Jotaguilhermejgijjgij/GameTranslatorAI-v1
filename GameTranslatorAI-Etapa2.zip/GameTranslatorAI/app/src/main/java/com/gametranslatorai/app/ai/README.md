# ai

Reservado para a camada de inteligência artificial/tradução via provedor
externo. Nenhuma chave de API será colocada no código-fonte. A
arquitetura será feita por interface, permitindo trocar/adicionar
provedores de IA no futuro sem reescrever o app.

Será implementado na Etapa 8. Requer configuração de uma API externa de
tradução/IA (chave de API), que ainda não existe no projeto.
