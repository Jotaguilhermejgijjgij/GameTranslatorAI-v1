# ocr

Reservado para o reconhecimento de texto na tela (OCR): detecção de
regiões de texto, processamento periódico no modo automático e
otimizações para reduzir consumo de bateria/CPU.

Será implementado na Etapa 7. Depende da captura de tela (`capture/`,
Etapa 6) já estar funcionando.
