# capture

Reservado para a captura de tela usando a API oficial do Android
(MediaProjection). Vai pedir a permissão de captura explicitamente ao
usuário — nunca de forma oculta.

Será implementado na Etapa 6. Requer permissão especial do Android,
concedida em tempo de execução pelo usuário.
