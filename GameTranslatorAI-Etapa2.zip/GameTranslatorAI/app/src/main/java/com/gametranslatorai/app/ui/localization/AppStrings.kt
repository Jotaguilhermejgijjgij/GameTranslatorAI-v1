package com.gametranslatorai.app.ui.localization

import androidx.compose.runtime.staticCompositionLocalOf
import com.gametranslatorai.app.settings.model.AppLanguage

/**
 * Textos da interface do GameTranslatorAI.
 *
 * Etapa 2: localização feita dentro do próprio app (não depende da troca
 * de idioma do sistema operacional), cobrindo as telas já existentes
 * (Splash, Home e Configurações). Novas telas devem adicionar seus
 * textos aqui, em ambos os idiomas, para nunca misturar Português e
 * Inglês quando apenas um estiver selecionado.
 */
data class AppStrings(
    val appName: String,
    val homeSubtitle: String,
    val settingsTitle: String,
    val settingsContentDescription: String,
    val backContentDescription: String,
    val appLanguageSectionTitle: String,
    val appLanguageSectionDescription: String,
    val targetLanguageSectionTitle: String,
    val targetLanguageSectionDescription: String
)

private val StringsPtBr = AppStrings(
    appName = "GameTranslatorAI",
    homeSubtitle = "Em breve você poderá selecionar um jogo ou aplicativo para traduzir.",
    settingsTitle = "Configurações",
    settingsContentDescription = "Configurações",
    backContentDescription = "Voltar",
    appLanguageSectionTitle = "Idioma do aplicativo",
    appLanguageSectionDescription = "Idioma usado nos textos e menus do GameTranslatorAI.",
    targetLanguageSectionTitle = "Traduzir jogo para",
    targetLanguageSectionDescription = "Idioma para o qual o conteúdo do jogo será traduzido."
)

private val StringsEn = AppStrings(
    appName = "GameTranslatorAI",
    homeSubtitle = "Soon you'll be able to select a game or app to translate.",
    settingsTitle = "Settings",
    settingsContentDescription = "Settings",
    backContentDescription = "Back",
    appLanguageSectionTitle = "App language",
    appLanguageSectionDescription = "Language used in GameTranslatorAI's texts and menus.",
    targetLanguageSectionTitle = "Translate game to",
    targetLanguageSectionDescription = "Language the game's content will be translated into."
)

fun stringsFor(language: AppLanguage): AppStrings = when (language) {
    AppLanguage.PT_BR -> StringsPtBr
    AppLanguage.EN -> StringsEn
}

/** Disponibiliza [AppStrings] para toda a árvore de composables. */
val LocalAppStrings = staticCompositionLocalOf { StringsPtBr }
