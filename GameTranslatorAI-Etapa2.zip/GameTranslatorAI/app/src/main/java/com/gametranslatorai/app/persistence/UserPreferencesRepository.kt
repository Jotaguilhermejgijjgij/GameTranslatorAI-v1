package com.gametranslatorai.app.persistence

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.gametranslatorai.app.settings.model.AppLanguage
import com.gametranslatorai.app.settings.model.TargetLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "gametranslatorai_settings"
)

/**
 * Conjunto de preferências do usuário lidas da persistência local.
 *
 * Etapa 2: apenas idioma da interface e idioma de tradução do jogo.
 * Etapa 3 vai expandir esta mesma classe com as demais categorias
 * (cor do tema, OCR, IA, app selecionado, etc.), sem quebrar o que já
 * existe aqui.
 */
data class UserSettings(
    val appLanguage: AppLanguage = AppLanguage.DEFAULT,
    val targetLanguage: TargetLanguage = TargetLanguage.DEFAULT
)

/**
 * Camada de persistência local usando Jetpack DataStore (Preferences).
 * Substitui SharedPreferences: é assíncrono, baseado em Flow e seguro
 * contra corrupção de dados/escritas concorrentes.
 *
 * As preferências salvas aqui sobrevivem ao fechamento do aplicativo,
 * pois ficam gravadas em um arquivo próprio do app no armazenamento do
 * aparelho (não são apagadas ao encerrar o processo).
 */
class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val TARGET_LANGUAGE = stringPreferencesKey("target_language")
    }

    /** Fluxo reativo com as preferências atuais, atualizado a cada alteração. */
    val userSettings: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            appLanguage = AppLanguage.fromStorageKey(prefs[Keys.APP_LANGUAGE]),
            targetLanguage = TargetLanguage.fromStorageKey(prefs[Keys.TARGET_LANGUAGE])
        )
    }

    suspend fun setAppLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs -> prefs[Keys.APP_LANGUAGE] = language.storageKey }
    }

    suspend fun setTargetLanguage(language: TargetLanguage) {
        context.dataStore.edit { prefs -> prefs[Keys.TARGET_LANGUAGE] = language.storageKey }
    }
}
