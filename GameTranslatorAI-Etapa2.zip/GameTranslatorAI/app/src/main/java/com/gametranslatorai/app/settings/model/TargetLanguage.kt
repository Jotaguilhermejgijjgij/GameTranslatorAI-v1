package com.gametranslatorai.app.settings.model

/**
 * Idioma para o qual o conteúdo do jogo/aplicativo será traduzido.
 *
 * Não deve ser confundido com [AppLanguage], que é o idioma da interface
 * do próprio GameTranslatorAI. Esta preferência é usada pelo motor de
 * tradução, que será implementado em etapas futuras (Etapa 8/10).
 */
enum class TargetLanguage(val storageKey: String, val nativeName: String) {
    PT(storageKey = "pt", nativeName = "Português"),
    EN(storageKey = "en", nativeName = "English"),
    ES(storageKey = "es", nativeName = "Español");

    companion object {
        val DEFAULT = PT

        fun fromStorageKey(key: String?): TargetLanguage =
            entries.firstOrNull { it.storageKey == key } ?: DEFAULT
    }
}
