# GameTranslatorAI

Status atual: **Etapa 2 concluída** (a Etapa 1 continua intacta e é a base
de tudo abaixo). Veja "Etapa 2" mais abaixo para o que foi adicionado.

---

## Etapa 1: Fundação do projeto

Este é o projeto Android real (Kotlin + Jetpack Compose) do GameTranslatorAI,
na sua Etapa 1: a base do app, compilável, com a arquitetura de pastas
preparada para todas as etapas seguintes.

## O que esta etapa entrega

- Projeto Gradle/Kotlin completo (`build.gradle.kts`, `settings.gradle.kts`,
  `app/build.gradle.kts`), pronto para abrir no Android Studio.
- App single-activity com Jetpack Compose e Material 3.
- Tema branco por padrão, com cantos arredondados (Etapa 2 vai ligar isso
  ao sistema de cores escolhível).
- Splash screen simples com o nome do app.
- Navegação real entre 3 telas: Splash → Home → Configurações.
- Ícone do app provisório (geométrico, vetorial) — ver seção "Ícone" abaixo.
- Estrutura de pacotes (pastas) já criada para todos os módulos futuros,
  cada uma com um `README.md` explicando o que vai entrar ali e em qual
  etapa: `settings/`, `translation/`, `ocr/`, `capture/`, `ai/`,
  `persistence/`, `appselection/`, além de `ui/theme/` e `ui/navigation/`
  já implementados.

## O que NÃO está nesta etapa (de propósito)

Nada de tradução, OCR, captura de tela, IA, seleção de app ou persistência
de configurações foi implementado ainda — isso viria nas Etapas 2 a 11.
As telas de Home e Configurações mostram apenas texto explicando o que vem
a seguir, sem nenhum botão "falso".

## Como abrir o projeto

1. Abra a pasta `GameTranslatorAI/` no Android Studio (versão recente,
   compatível com AGP 8.5.x / Gradle 8.7).
2. O Android Studio vai detectar que faltam os arquivos binários do Gradle
   Wrapper (`gradle/wrapper/gradle-wrapper.jar`, `gradlew`, `gradlew.bat`)
   e oferecer para gerá-los automaticamente ao sincronizar. Aceite a
   sincronização.
   - Alternativa manual (se tiver o Gradle instalado localmente):
     rode `gradle wrapper --gradle-version 8.7` dentro da pasta do projeto.
3. Depois da sincronização, rode o app em um emulador ou aparelho físico
   (botão Run ▶) para gerar e instalar o APK de debug.

> Por que o wrapper não veio pronto? O ambiente onde este projeto foi
> gerado não tem acesso à internet para baixar o `gradle-wrapper.jar`
> (arquivo binário). Isso é normal e resolvido automaticamente pelo
> Android Studio na primeira sincronização, ou manualmente como descrito
> acima.

## Ícone do aplicativo

O ícone atual é um placeholder geométrico (vetorial, sem depender de
imagens PNG), só para o app ter um ícone válido e compilar corretamente.
Ele já está preparado nos formatos necessários:

- `res/mipmap-anydpi-v26/ic_launcher.xml` (+ `_round`): ícone adaptativo,
  Android 8.0 (API 26) em diante.
- `res/mipmap/ic_launcher.xml` (+ `_round`): versão simples para Android
  7.0/7.1 (API 24–25).

Na Etapa 11, basta substituir os vetores em `res/drawable/ic_launcher_*.xml`
(ou os arquivos de mipmap) pela arte final do GameTranslatorAI.

## Checklist de transparência (item 16 do pedido original)

1. **O que já funciona de verdade:** navegação entre telas, tema visual
   (cores/tipografia/formas), splash screen, estrutura de projeto Gradle
   compilável.
2. **O que precisa de configuração adicional:** nada nesta etapa além do
   próprio Android Studio/Gradle Wrapper (ver seção acima).
3. **O que precisa de API externa:** nada ainda — a camada de IA/tradução
   (pasta `ai/`) só será implementada na Etapa 8, e vai exigir uma chave de
   API de um provedor de tradução/IA fornecida por você.
4. **O que precisa de permissão especial do Android:** nada ainda —
   captura de tela (`MediaProjection`) e overlay (`SYSTEM_ALERT_WINDOW`)
   serão pedidos explicitamente ao usuário nas Etapas 6 e 9.
5. **O que ainda precisa ser desenvolvido:** tudo o que está listado nas
   Etapas 2 a 12 do planejamento (cores, idiomas, persistência, seleção de
   app, captura de tela, OCR, IA, caixa de tradução, modos automático/
   manual, ícone final, revisão de compilação completa).

## Estrutura de pastas

```
GameTranslatorAI/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/…
        └── java/com/gametranslatorai/app/
            ├── GameTranslatorApp.kt
            ├── MainActivity.kt
            ├── ui/
            │   ├── navigation/NavGraph.kt
            │   ├── screens/ (Splash, Home, Settings)
            │   └── theme/ (Color, Type, Theme)
            ├── settings/        (modelos: Etapa 2 ✅ | tela por categorias: Etapa 3)
            ├── persistence/     (idiomas: Etapa 2 ✅ | demais categorias: Etapa 3)
            ├── ui/localization/ (Etapa 2 ✅)
            ├── appselection/    (Etapa 5)
            ├── capture/         (Etapa 6)
            ├── ocr/             (Etapa 7)
            ├── ai/              (Etapa 8)
            └── translation/     (Etapa 10)
```

---

## Etapa 2: Idiomas e configurações

Adicionado **sobre** a Etapa 1, sem remover nada dela.

### O que foi implementado (de verdade, funcional)

- **Idioma do aplicativo** (tela de Configurações): Português (Brasil) ou
  English. Toda a interface (Splash, Home, Configurações) troca de idioma
  imediatamente ao selecionar, sem misturar os dois idiomas.
- **Idioma de tradução do jogo** (tela de Configurações): Português,
  English ou Español.
- **Persistência real** das duas escolhas usando Jetpack DataStore
  (`persistence/UserPreferencesRepository.kt`): os valores são gravados em
  disco a cada seleção e recarregados automaticamente na próxima vez que
  o app for aberto — inclusive após fechar completamente o app ou reiniciar
  o aparelho.
- Textos de desenvolvimento ("Estrutura base do app (Etapa 1)" etc.) foram
  removidos da interface. A tela inicial agora mostra apenas uma frase
  neutra explicando o que vem a seguir, no idioma escolhido.
- Layout das novas opções segue o padrão visual já definido na Etapa 1
  (cartões com cantos arredondados, espaçamento consistente, Material 3).

### Novos arquivos

- `settings/model/AppLanguage.kt` — enum do idioma da interface.
- `settings/model/TargetLanguage.kt` — enum do idioma de tradução do jogo.
- `persistence/UserPreferencesRepository.kt` — leitura/escrita via DataStore.
- `ui/localization/AppStrings.kt` — textos da interface em PT-BR e EN.

### Arquivos alterados (Etapa 1 preservada, apenas estendida)

- `MainActivity.kt`: agora cria o repositório de preferências e fornece os
  textos localizados para toda a árvore de telas.
- `ui/navigation/NavGraph.kt`: passa as preferências e os callbacks de
  salvar para a tela de Configurações.
- `ui/screens/SettingsScreen.kt`: ganhou os dois seletores de idioma reais.
- `ui/screens/HomeScreen.kt` e `ui/screens/SplashScreen.kt`: textos
  passaram a vir de `AppStrings` em vez de string fixa em português.
- `app/build.gradle.kts`: adicionada a dependência
  `androidx.datastore:datastore-preferences:1.1.1`.

### O que ainda NÃO foi feito (de propósito, conforme pedido)

- OCR: não implementado (Etapa 7).
- Tradução por IA: não implementado (Etapa 8/10).
- "Idioma do jogo" (idioma original do jogo, distinto do idioma de
  tradução) e as demais categorias de configuração (Aparência, cor do
  tema, etc.): ficam para as Etapas 2-cor e 3, conforme planejamento.

### Checklist de transparência

1. **O que já funciona de verdade:** seleção e persistência do idioma da
   interface e do idioma de tradução do jogo; troca de idioma da UI em
   tempo real, sem reiniciar o app.
2. **O que precisa de configuração adicional:** nada — funciona
   imediatamente após compilar.
3. **O que precisa de API externa:** nada nesta etapa.
4. **O que precisa de permissão do Android:** nada nesta etapa.
5. **O que ainda precisa ser desenvolvido:** sistema de cores/tema
   selecionável, demais categorias de configurações (Etapa 3), seleção de
   app (Etapa 5), captura de tela (Etapa 6), OCR (Etapa 7), IA (Etapa 8),
   caixa de tradução (Etapa 9) e orquestração automática/manual
   (Etapa 10). A numeração exata das próximas etapas será combinada com
   você antes de cada implementação.
