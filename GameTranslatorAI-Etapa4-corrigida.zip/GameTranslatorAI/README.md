# GameTranslatorAI

Status atual: **Etapa 4 concluída** (as Etapas 1, 2 e 3 continuam intactas
e são a base de tudo abaixo). Veja "Etapa 4" mais abaixo para o que foi
adicionado.

---

## Etapa 1: Fundação do projeto

Este é o projeto Android real (Kotlin + Jetpack Compose) do GameTranslatorAI,
na sua Etapa 1: a base do app, compilável, com a arquitetura de pastas
preparada para todas as etapas seguintes.

## O que esta etapa entrega

- Projeto Gradle/Kotlin completo (`build.gradle.kts`, `settings.gradle.kts`,
  `app/build.gradle.kts`), pronto para abrir no Android Studio.
- App single-activity com Jetpack Compose e Material 3.
- Tema branco por padrão, com cantos arredondados (Etapa 2 vai ligar isso
  ao sistema de cores escolhível).
- Splash screen simples com o nome do app.
- Navegação real entre 3 telas: Splash → Home → Configurações.
- Ícone do app provisório (geométrico, vetorial) — ver seção "Ícone" abaixo.
- Estrutura de pacotes (pastas) já criada para todos os módulos futuros,
  cada uma com um `README.md` explicando o que vai entrar ali e em qual
  etapa: `settings/`, `translation/`, `ocr/`, `capture/`, `ai/`,
  `persistence/`, `appselection/`, além de `ui/theme/` e `ui/navigation/`
  já implementados.

## O que NÃO está nesta etapa (de propósito)

Nada de tradução, OCR, captura de tela, IA, seleção de app ou persistência
de configurações foi implementado ainda — isso viria nas Etapas 2 a 11.
As telas de Home e Configurações mostram apenas texto explicando o que vem
a seguir, sem nenhum botão "falso".

## Como abrir o projeto

1. Abra a pasta `GameTranslatorAI/` no Android Studio (versão recente,
   compatível com AGP 8.5.x / Gradle 8.7).
2. O Android Studio vai detectar que faltam os arquivos binários do Gradle
   Wrapper (`gradle/wrapper/gradle-wrapper.jar`, `gradlew`, `gradlew.bat`)
   e oferecer para gerá-los automaticamente ao sincronizar. Aceite a
   sincronização.
   - Alternativa manual (se tiver o Gradle instalado localmente):
     rode `gradle wrapper --gradle-version 8.7` dentro da pasta do projeto.
3. Depois da sincronização, rode o app em um emulador ou aparelho físico
   (botão Run ▶) para gerar e instalar o APK de debug.

> Por que o wrapper não veio pronto? O ambiente onde este projeto foi
> gerado não tem acesso à internet para baixar o `gradle-wrapper.jar`
> (arquivo binário). Isso é normal e resolvido automaticamente pelo
> Android Studio na primeira sincronização, ou manualmente como descrito
> acima.

## Ícone do aplicativo

O ícone atual é um placeholder geométrico (vetorial, sem depender de
imagens PNG), só para o app ter um ícone válido e compilar corretamente.
Ele já está preparado nos formatos necessários:

- `res/mipmap-anydpi-v26/ic_launcher.xml` (+ `_round`): ícone adaptativo,
  Android 8.0 (API 26) em diante.
- `res/mipmap/ic_launcher.xml` (+ `_round`): versão simples para Android
  7.0/7.1 (API 24–25).

Na Etapa 11, basta substituir os vetores em `res/drawable/ic_launcher_*.xml`
(ou os arquivos de mipmap) pela arte final do GameTranslatorAI.

## Checklist de transparência (item 16 do pedido original)

1. **O que já funciona de verdade:** navegação entre telas, tema visual
   (cores/tipografia/formas), splash screen, estrutura de projeto Gradle
   compilável.
2. **O que precisa de configuração adicional:** nada nesta etapa além do
   próprio Android Studio/Gradle Wrapper (ver seção acima).
3. **O que precisa de API externa:** nada ainda — a camada de IA/tradução
   (pasta `ai/`) só será implementada na Etapa 8, e vai exigir uma chave de
   API de um provedor de tradução/IA fornecida por você.
4. **O que precisa de permissão especial do Android:** nada ainda —
   captura de tela (`MediaProjection`) e overlay (`SYSTEM_ALERT_WINDOW`)
   serão pedidos explicitamente ao usuário nas Etapas 6 e 9.
5. **O que ainda precisa ser desenvolvido:** tudo o que está listado nas
   Etapas 2 a 12 do planejamento (cores, idiomas, persistência, seleção de
   app, captura de tela, OCR, IA, caixa de tradução, modos automático/
   manual, ícone final, revisão de compilação completa).

## Estrutura de pastas

```
GameTranslatorAI/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/…
        └── java/com/gametranslatorai/app/
            ├── GameTranslatorApp.kt
            ├── MainActivity.kt
            ├── ui/
            │   ├── navigation/NavGraph.kt
            │   ├── screens/ (Splash, Home, Settings)
            │   └── theme/ (Color, Type, Theme)
            ├── settings/        (modelos: Etapa 2 ✅ | tela por categorias: futura)
            ├── persistence/     (idiomas: Etapa 2 ✅ | demais categorias: futura)
            ├── ui/localization/ (Etapa 2 ✅)
            ├── appselection/    (futura)
            ├── capture/         (Etapa 3 ✅)
            ├── ocr/             (Etapa 3 ✅)
            ├── ai/              (Etapa 4 ✅)
            └── translation/     (Etapa 3 ✅ | Etapa 4 ✅)
```

---

## Etapa 2: Idiomas e configurações

Adicionado **sobre** a Etapa 1, sem remover nada dela.

### O que foi implementado (de verdade, funcional)

- **Idioma do aplicativo** (tela de Configurações): Português (Brasil) ou
  English. Toda a interface (Splash, Home, Configurações) troca de idioma
  imediatamente ao selecionar, sem misturar os dois idiomas.
- **Idioma de tradução do jogo** (tela de Configurações): Português,
  English ou Español.
- **Persistência real** das duas escolhas usando Jetpack DataStore
  (`persistence/UserPreferencesRepository.kt`): os valores são gravados em
  disco a cada seleção e recarregados automaticamente na próxima vez que
  o app for aberto — inclusive após fechar completamente o app ou reiniciar
  o aparelho.
- Textos de desenvolvimento ("Estrutura base do app (Etapa 1)" etc.) foram
  removidos da interface. A tela inicial agora mostra apenas uma frase
  neutra explicando o que vem a seguir, no idioma escolhido.
- Layout das novas opções segue o padrão visual já definido na Etapa 1
  (cartões com cantos arredondados, espaçamento consistente, Material 3).

### Novos arquivos

- `settings/model/AppLanguage.kt` — enum do idioma da interface.
- `settings/model/TargetLanguage.kt` — enum do idioma de tradução do jogo.
- `persistence/UserPreferencesRepository.kt` — leitura/escrita via DataStore.
- `ui/localization/AppStrings.kt` — textos da interface em PT-BR e EN.

### Arquivos alterados (Etapa 1 preservada, apenas estendida)

- `MainActivity.kt`: agora cria o repositório de preferências e fornece os
  textos localizados para toda a árvore de telas.
- `ui/navigation/NavGraph.kt`: passa as preferências e os callbacks de
  salvar para a tela de Configurações.
- `ui/screens/SettingsScreen.kt`: ganhou os dois seletores de idioma reais.
- `ui/screens/HomeScreen.kt` e `ui/screens/SplashScreen.kt`: textos
  passaram a vir de `AppStrings` em vez de string fixa em português.
- `app/build.gradle.kts`: adicionada a dependência
  `androidx.datastore:datastore-preferences:1.1.1`.

### O que ainda NÃO foi feito (de propósito, conforme pedido)

- OCR: não implementado (Etapa 7).
- Tradução por IA: não implementado (Etapa 8/10).
- "Idioma do jogo" (idioma original do jogo, distinto do idioma de
  tradução) e as demais categorias de configuração (Aparência, cor do
  tema, etc.): ficam para as Etapas 2-cor e 3, conforme planejamento.

### Checklist de transparência

1. **O que já funciona de verdade:** seleção e persistência do idioma da
   interface e do idioma de tradução do jogo; troca de idioma da UI em
   tempo real, sem reiniciar o app.
2. **O que precisa de configuração adicional:** nada — funciona
   imediatamente após compilar.
3. **O que precisa de API externa:** nada nesta etapa.
4. **O que precisa de permissão do Android:** nada nesta etapa.
5. **O que ainda precisa ser desenvolvido:** sistema de cores/tema
   selecionável, demais categorias de configurações (Etapa 3), seleção de
   app (Etapa 5), captura de tela (Etapa 6), OCR (Etapa 7), IA (Etapa 8),
   caixa de tradução (Etapa 9) e orquestração automática/manual
   (Etapa 10). A numeração exata das próximas etapas será combinada com
   você antes de cada implementação.

---

## Etapa 3: Detecção automática de texto na tela

Adicionado **sobre** as Etapas 1 e 2, sem remover nada delas.

### Fluxo implementado (real, de ponta a ponta)

1. Na tela inicial, o usuário toca em "Iniciar modo de tradução".
2. O Android exibe o diálogo **oficial** do sistema pedindo autorização
   para capturar a tela (`MediaProjectionManager`). Nada é capturado antes
   dessa confirmação explícita do usuário.
3. Uma vez autorizado, um **serviço em primeiro plano**
   (`ScreenCaptureService`) inicia — com notificação visível, como o
   Android exige — e mantém a sessão de captura viva.
4. A cada 1,5s, o app captura o quadro mais recente da tela
   (`ScreenCaptureController`, via `VirtualDisplay` + `ImageReader`).
   Quadros repetidos (tela sem mudança) são descartados antes de gastar
   processamento com OCR (`FrameChangeDetector`).
5. Cada quadro novo é processado pelo **Google ML Kit Text Recognition**
   (`TextRecognitionEngine`), que roda localmente no aparelho, offline,
   sem chave de API. Nenhum texto é inventado: só aparece o que o OCR
   realmente reconheceu.
6. Cada texto reconhecido é entregue a `DetectedTextPipeline` — a
   estrutura que a próxima etapa (tradução por IA) vai consumir — e
   também aparece em tempo real na tela inicial, como confirmação visual
   de que a detecção está funcionando de verdade.
7. Tocar em "Parar modo de tradução" encerra o serviço e libera todos os
   recursos (VirtualDisplay, ImageReader, MediaProjection, OCR).

### Novos arquivos

- `capture/ScreenCaptureService.kt` — serviço em primeiro plano que
  hospeda a sessão de `MediaProjection` autorizada.
- `capture/ScreenCaptureController.kt` — captura periódica de quadros e
  encaminhamento ao OCR.
- `capture/FrameChangeDetector.kt` — evita reprocessar quadros repetidos.
- `capture/ScreenCaptureState.kt` — estado compartilhado (ativo/inativo).
- `ocr/TextRecognitionEngine.kt` — OCR real via ML Kit (offline).
- `ocr/DetectedText.kt` — modelo de um texto detectado.
- `translation/DetectedTextPipeline.kt` — estrutura de entrega dos textos
  detectados para a Etapa 4 (tradução por IA).

### Arquivos alterados (Etapas 1 e 2 preservadas, apenas estendidas)

- `AndroidManifest.xml`: adicionadas as permissões
  `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION` e
  `POST_NOTIFICATIONS`, e a declaração do `ScreenCaptureService`.
- `app/build.gradle.kts`: adicionada a dependência
  `com.google.mlkit:text-recognition:16.0.1`.
- `ui/localization/AppStrings.kt`: adicionados os textos do modo de
  tradução (em PT-BR e EN); nenhum campo existente foi removido.
- `ui/screens/HomeScreen.kt`: ganhou o botão de iniciar/parar o modo de
  tradução e a lista de textos detectados em tempo real. Nenhum texto de
  desenvolvimento ("Etapa 1/2/3") é exibido ao usuário.

### O que ainda NÃO foi feito (de propósito, conforme pedido)

- Identificação de idioma do texto detectado: não implementado (Etapa 4).
- Tradução por IA: não implementado (Etapa 4).
- Caixa de tradução sobre o jogo: não implementado (Etapa 9).
- Frequência de captura configurável pelo usuário: fixa em 1500ms por
  enquanto.

### Checklist de transparência

1. **O que já funciona de verdade:** pedido de autorização oficial de
   captura de tela; captura periódica real da tela; reconhecimento real
   de texto via OCR offline; entrega estruturada do texto detectado para
   a próxima etapa; toda a Etapa 1 e Etapa 2 continuam funcionando
   (splash, navegação, tema, idiomas, persistência).
2. **O que precisa de configuração adicional:** nada — funciona
   imediatamente após compilar e conceder a permissão de captura quando
   solicitada.
3. **O que precisa de API externa:** nada nesta etapa (o OCR é 100%
   local/offline). A tradução por IA da Etapa 4 é que vai precisar de uma
   API externa.
4. **O que precisa de permissão do Android:** a autorização de captura de
   tela (concedida pelo usuário no diálogo do sistema a cada início do
   modo de tradução — não é possível deixá-la "sempre concedida" por
   política do Android) e, no Android 13+, a permissão de notificações
   (opcional: sem ela, a captura funciona, só a notificação fica oculta).
5. **O que ainda precisa ser desenvolvido:** identificação de idioma +
   tradução por IA (Etapa 4), caixa de tradução sobreposta (etapa
   futura), seleção de app/jogo, cor do tema e demais categorias de
   configuração.

---

## Etapa 4: Tradução automática por IA

Adicionado **sobre** as Etapas 1, 2 e 3, sem remover nada delas.

### Fluxo implementado (real, de ponta a ponta)

1. O OCR (Etapa 3) detecta um texto na tela e o entrega para
   `DetectedTextPipeline`.
2. `AutoTranslationEngine` (novo, liga junto com o modo de tradução)
   recebe o texto, consulta o idioma de destino salvo pelo usuário nas
   Configurações (Etapa 2) e verifica se esse texto exato já foi traduzido
   recentemente para esse idioma — se sim, reaproveita o resultado em vez
   de chamar a IA de novo.
3. Se for um texto novo, chama a camada de IA (`ai/OnDeviceTranslationProvider`):
   primeiro identifica automaticamente o idioma de origem do texto
   (Google ML Kit Language Identification), depois traduz para o idioma
   de destino (Google ML Kit Translate) — ambos rodando **no aparelho**,
   sem chave de API e sem custo.
4. O par (texto original, tradução) fica disponível em
   `AutoTranslationEngine.translatedText`, pronto para a etapa de
   apresentação (caixa de legenda/overlay), e também aparece em tempo
   real na tela inicial como confirmação visual de que a tradução está
   funcionando de verdade — sem qualquer frase pré-programada.

**Exemplo real:** o texto "Hello, my friend." detectado pelo OCR, com
"Português" escolhido em Configurações, é identificado como inglês e
traduzido pela IA para algo como "Oi, meu amigo." — a frase exata pode
variar de acordo com o modelo do ML Kit, mas a tradução é sempre gerada
de verdade, nunca copiada de uma lista fixa.

### Novos arquivos

- `ai/TranslationProvider.kt` — contrato da camada de IA + tipos de
  resultado (nunca inventa tradução).
- `ai/OnDeviceTranslationProvider.kt` — provedor real de IA (Google ML
  Kit, on-device, sem chave de API).
- `translation/AutoTranslationEngine.kt` — orquestra OCR → IA → resultado
  traduzido; evita retraduzir o mesmo texto repetidamente.
- `translation/TranslatedText.kt` — modelo do texto já traduzido.

### Arquivos alterados (Etapas 1, 2 e 3 preservadas, apenas estendidas)

- `AndroidManifest.xml`: adicionada a permissão `INTERNET` (necessária
  apenas para o ML Kit baixar o modelo de tradução na primeira vez —
  documentado no próprio manifesto).
- `app/build.gradle.kts`: adicionadas as dependências
  `com.google.mlkit:language-id:17.0.6` e `com.google.mlkit:translate:17.0.3`.
- `capture/ScreenCaptureService.kt`: passou a iniciar/parar o
  `AutoTranslationEngine` junto com a captura de tela. A lógica de
  captura/OCR em si não foi alterada.
- `ui/localization/AppStrings.kt`: adicionados os textos da seção de
  traduções (PT-BR e EN); nenhum campo existente foi removido.
- `ui/screens/HomeScreen.kt`: ganhou a seção "Traduções automáticas".
  Nenhum texto de desenvolvimento ("Etapa 4" etc.) é exibido ao usuário.

### O que ainda NÃO foi feito (de propósito, conforme pedido)

- Substituição do texto original do jogo: não implementado.
- Caixa de legenda/overlay definitiva sobre o jogo: não implementado
  (etapa futura). O resultado da tradução já está pronto e disponível
  (`AutoTranslationEngine.translatedText`) para quando essa etapa vier.

### Correção pós-teste

Depois do primeiro build reportado com erro, dois pontos de risco foram
revisados e corrigidos em `ai/OnDeviceTranslationProvider.kt` e
`app/build.gradle.kts`:

1. A chamada `translator.downloadModelIfNeeded()` (sem argumentos) foi
   trocada pela forma oficialmente documentada,
   `translator.downloadModelIfNeeded(DownloadConditions.Builder().build())`,
   removendo a dependência de uma sobrecarga que não era garantida.
2. As versões do ML Kit foram ajustadas para
   `com.google.mlkit:language-id:17.0.4` e
   `com.google.mlkit:translate:17.0.2` — versões com publicação
   confirmada no Maven do Google. Como este ambiente de geração do
   projeto não tem acesso à internet para consultar o Maven em tempo
   real, se o Android Studio ainda assim não conseguir resolver alguma
   dessas versões, use a sugestão automática de versão mais recente que
   o próprio Android Studio oferece (não é necessário mudar mais nada no
   código para isso).

### Segurança e custos

- Nenhuma chave de API está no código-fonte — o provedor ativo
  (ML Kit on-device) não usa nenhuma.
- Nenhuma chamada a serviço pago é feita neste projeto.
- A arquitetura (`TranslationProvider`) já permite adicionar um provedor
  em nuvem no futuro sem alterar o resto do app — o passo a passo de como
  fazer isso com segurança está documentado em `ai/README.md`.

### Checklist de transparência

1. **O que já funciona de verdade:** identificação automática de idioma,
   tradução automática para PT/EN/ES conforme escolhido na Etapa 2, sem
   qualquer intervenção manual do usuário; reaproveitamento de traduções
   já feitas para o mesmo texto; toda a Etapa 1, 2 e 3 continuam
   funcionando.
2. **O que precisa de configuração adicional:** nada — funciona
   imediatamente após compilar. Na primeira tradução de um novo par de
   idiomas, é necessária uma conexão com a internet para o ML Kit baixar
   o modelo (poucos MB, uma única vez); depois disso, funciona offline.
3. **O que precisa de API externa:** nada nesta etapa — a tradução é
   100% on-device via Google ML Kit, gratuita e sem chave de API.
4. **O que precisa de permissão do Android:** `INTERNET` (normal, não
   exige autorização do usuário) apenas para o download do modelo.
5. **O que ainda precisa ser desenvolvido:** apresentação da tradução
   sobre o jogo (caixa de legenda/overlay ou substituição do texto
   original), seleção de app/jogo, cor do tema e demais categorias de
   configuração.
