plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gametranslatorai.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.gametranslatorai.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.4.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isDebuggable = true
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core / Kotlin
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Persistência local das preferências do usuário (Etapa 2)
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // OCR real, embutido no app, funciona offline (Etapa 3)
    implementation("com.google.mlkit:text-recognition:16.0.1")

    // Identificação de idioma e tradução por IA on-device, sem chave de
    // API e sem custo (Etapa 4).
    // OBS.: se o Gradle não conseguir resolver alguma destas versões
    // (erro "Could not find..."), abra o arquivo no Android Studio e use
    // "Suggestion" no aviso de dependência para pegar a versão mais
    // recente publicada em https://developers.google.com/ml-kit/release-notes
    // — não é necessário mudar mais nada no código para isso.
    implementation("com.google.mlkit:language-id:17.0.4")
    implementation("com.google.mlkit:translate:17.0.2")

    // Jetpack Compose (UI declarativa, Material 3)
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")

    // Navegação entre telas (splash -> home -> configurações)
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Testes
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.06.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
