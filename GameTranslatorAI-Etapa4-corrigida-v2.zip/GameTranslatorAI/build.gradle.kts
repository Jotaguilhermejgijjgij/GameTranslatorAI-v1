// Arquivo de build de nível raiz. Apenas declara os plugins que os
// módulos do projeto podem aplicar; nenhuma configuração vai aqui.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
