package com.gametranslatorai.app.capture

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Estado compartilhado indicando se o modo de tradução (captura de tela
 * + OCR) está ativo no momento.
 *
 * É necessário porque quem controla a captura de verdade é o
 * [ScreenCaptureService] (um serviço em primeiro plano), não a interface
 * diretamente — este objeto é a fonte única de verdade que a tela inicial
 * observa para saber se deve mostrar "Iniciar" ou "Parar".
 */
object ScreenCaptureState {

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    internal fun setRunning(running: Boolean) {
        _isRunning.value = running
    }
}
