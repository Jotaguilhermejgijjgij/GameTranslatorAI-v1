# persistence

Camada de persistência local das preferências do usuário, usando Jetpack
DataStore (Preferences).

**Status (Etapa 2):** implementado — `UserPreferencesRepository.kt` já
salva e recupera de verdade o idioma da interface e o idioma de tradução
do jogo. As escolhas sobrevivem ao fechamento do aplicativo.

**Pendente (Etapa 3):** expandir a mesma estrutura para as demais
categorias de configuração (cor do tema, ativar/desativar tradução
automática, configurações de OCR, provedor de IA, app selecionado, etc.),
sem quebrar o que já está salvo aqui.
