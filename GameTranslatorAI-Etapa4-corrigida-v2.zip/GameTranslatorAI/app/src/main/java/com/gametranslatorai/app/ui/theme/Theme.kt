package com.gametranslatorai.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

/**
 * Tema visual do GameTranslatorAI.
 *
 * Etapa 1: esquema de cores único e estático (branco como fundo, cinza
 * escuro como destaque), apenas para validar a base do app.
 *
 * Etapa 2 vai tornar isto dinâmico: o esquema de cores passará a ser
 * escolhido a partir da preferência salva do usuário (uma das 9 cores
 * definidas em "Cor do aplicativo"), lida da camada de persistência.
 */
private val LightColors = lightColorScheme(
    primary = AccentDefault,
    onPrimary = NeutralWhite,
    background = NeutralWhite,
    onBackground = NeutralBlack,
    surface = SurfaceLight,
    onSurface = NeutralBlack
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(20.dp)
)

@Composable
fun GameTranslatorAITheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = GameTranslatorTypography,
        shapes = AppShapes,
        content = content
    )
}
