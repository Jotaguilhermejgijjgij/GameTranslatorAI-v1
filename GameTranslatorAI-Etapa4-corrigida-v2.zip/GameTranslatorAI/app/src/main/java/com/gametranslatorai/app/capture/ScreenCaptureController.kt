package com.gametranslatorai.app.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.gametranslatorai.app.ocr.DetectedText
import com.gametranslatorai.app.ocr.TextRecognitionEngine
import com.gametranslatorai.app.translation.DetectedTextPipeline
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Controla a sessão real de captura de tela, usando os mecanismos
 * oficiais do Android: [MediaProjection] + [VirtualDisplay] + [ImageReader].
 *
 * Em vez de processar todo quadro disponível (o que rodaria a uma
 * frequência muito alta e consumiria bateria/CPU desnecessariamente),
 * roda um laço periódico que captura o quadro mais recente a cada
 * [CAPTURE_INTERVAL_MS] milissegundos. Quadros iguais ao anterior são
 * descartados pelo [FrameChangeDetector] antes de chamar o OCR.
 *
 * Nenhum texto é simulado: o [TextRecognitionEngine] só devolve o que
 * realmente reconheceu no quadro capturado, e cada texto reconhecido é
 * entregue ao [DetectedTextPipeline] para a próxima etapa (tradução por IA).
 */
class ScreenCaptureController(
    private val context: Context,
    private val mediaProjection: MediaProjection
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var captureJob: Job? = null

    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null

    private val ocrEngine = TextRecognitionEngine()
    private val frameChangeDetector = FrameChangeDetector()

    private var frameWidth = 0
    private var frameHeight = 0

    fun start() {
        val metrics = context.resources.displayMetrics
        frameWidth = metrics.widthPixels.coerceAtLeast(1)
        frameHeight = metrics.heightPixels.coerceAtLeast(1)
        val densityDpi = metrics.densityDpi

        val thread = HandlerThread("GameTranslatorAI-ScreenCapture").also { it.start() }
        handlerThread = thread
        val handler = Handler(thread.looper)

        val reader = ImageReader.newInstance(frameWidth, frameHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "GameTranslatorAI-VirtualDisplay",
            frameWidth,
            frameHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        captureJob = scope.launch {
            while (isActive) {
                captureAndRecognizeOnce()
                delay(CAPTURE_INTERVAL_MS)
            }
        }
    }

    private suspend fun captureAndRecognizeOnce() {
        val reader = imageReader ?: return
        val image = try {
            reader.acquireLatestImage()
        } catch (error: Exception) {
            null
        } ?: return

        try {
            val bitmap = imageToBitmap(image, frameWidth, frameHeight)
            image.close()
            if (bitmap == null) return

            if (!frameChangeDetector.isNewFrame(bitmap)) {
                bitmap.recycle()
                return
            }

            val recognizedLines = ocrEngine.recognizeText(bitmap)
            bitmap.recycle()

            val now = System.currentTimeMillis()
            recognizedLines.forEach { line ->
                DetectedTextPipeline.submit(DetectedText(text = line, detectedAtMillis = now))
            }
        } catch (error: Exception) {
            Log.w(TAG, "Falha ao processar um quadro capturado", error)
            try {
                image.close()
            } catch (_: Exception) {
                // já fechada; nada a fazer
            }
        }
    }

    /**
     * Converte o [Image] (formato RGBA_8888) devolvido pelo [ImageReader] em
     * um [Bitmap] utilizável, descartando o padding de linha que o Android
     * pode adicionar (rowStride != largura * pixelStride).
     */
    private fun imageToBitmap(image: Image, targetWidth: Int, targetHeight: Int): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * targetWidth

            val rawBitmap = Bitmap.createBitmap(
                targetWidth + rowPadding / pixelStride,
                targetHeight,
                Bitmap.Config.ARGB_8888
            )
            rawBitmap.copyPixelsFromBuffer(buffer)

            if (rowPadding == 0) {
                rawBitmap
            } else {
                val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, targetWidth, targetHeight)
                rawBitmap.recycle()
                cropped
            }
        } catch (error: Exception) {
            Log.w(TAG, "Falha ao converter quadro capturado em bitmap", error)
            null
        }
    }

    /** Libera todos os recursos nativos abertos por esta sessão de captura. */
    fun release() {
        captureJob?.cancel()
        captureJob = null

        virtualDisplay?.release()
        virtualDisplay = null

        imageReader?.close()
        imageReader = null

        handlerThread?.quitSafely()
        handlerThread = null

        ocrEngine.close()
    }

    companion object {
        private const val TAG = "ScreenCaptureController"

        /**
         * Intervalo entre capturas. Fixo por enquanto; uma configuração de
         * frequência de OCR ajustável pelo usuário fica para uma etapa
         * futura de ajuste fino de desempenho.
         */
        private const val CAPTURE_INTERVAL_MS = 1500L
    }
}
