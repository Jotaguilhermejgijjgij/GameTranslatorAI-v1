package com.gametranslatorai.app

import android.app.Application

/**
 * Classe Application do GameTranslatorAI.
 *
 * Etapa 1: apenas inicialização básica do processo, sem lógica adicional.
 *
 * Próximas etapas vão inicializar aqui, entre outras coisas:
 * - Etapa 2/3: sistema de tema e camada de persistência (DataStore).
 * - Etapa 9: preparação do serviço de overlay.
 */
class GameTranslatorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // TODO (Etapa 3): inicializar DataStore/preferências do usuário.
        // TODO (Etapa 2): carregar a cor de tema salva, se houver.
    }
}
