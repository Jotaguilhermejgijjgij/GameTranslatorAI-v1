package com.gametranslatorai.app.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.gametranslatorai.app.MainActivity
import com.gametranslatorai.app.persistence.UserPreferencesRepository
import com.gametranslatorai.app.translation.AutoTranslationEngine
import java.util.Locale

/**
 * Serviço em primeiro plano responsável por manter a sessão de captura de
 * tela (MediaProjection) enquanto o modo de tradução estiver ativo.
 *
 * O Android exige que a captura de tela rode dentro de um serviço em
 * primeiro plano, com uma notificação visível ao usuário — é para isso
 * que este serviço existe. **Nenhuma captura acontece sem o usuário
 * primeiro autorizar explicitamente** pela caixa de diálogo oficial do
 * sistema, disparada pelo [MediaProjectionManager] a partir da tela
 * inicial do app; este serviço só é iniciado depois que essa autorização
 * já foi concedida (resultCode/Intent recebidos como extras).
 *
 * A cada texto reconhecido pelo [com.gametranslatorai.app.ocr.TextRecognitionEngine]
 * (via [ScreenCaptureController]), o resultado é entregue para
 * [com.gametranslatorai.app.translation.DetectedTextPipeline].
 *
 * Etapa 4: este serviço também liga/desliga o
 * [com.gametranslatorai.app.translation.AutoTranslationEngine], que
 * consome esses textos, identifica o idioma e traduz automaticamente para
 * o idioma escolhido pelo usuário (Etapa 2) — tudo enquanto o modo de
 * tradução estiver ativo.
 */
class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var controller: ScreenCaptureController? = null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // O usuário revogou a permissão pelo painel do sistema
            // (ex.: tocando em "Parar transmissão"). Encerramos tudo.
            stopSelfSafely()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfSafely()
            return START_NOT_STICKY
        }

        val resultData = intent?.getParcelableExtraCompat(EXTRA_RESULT_DATA)
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0

        if (intent?.action != ACTION_START || resultData == null) {
            stopSelfSafely()
            return START_NOT_STICKY
        }

        createNotificationChannelIfNeeded()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val projectionManager = getSystemService(MediaProjectionManager::class.java)
        val projection = projectionManager?.getMediaProjection(resultCode, resultData)

        if (projection == null) {
            stopSelfSafely()
            return START_NOT_STICKY
        }

        mediaProjection = projection
        projection.registerCallback(projectionCallback, null)

        controller = ScreenCaptureController(
            context = applicationContext,
            mediaProjection = projection
        ).also { it.start() }

        AutoTranslationEngine.start(UserPreferencesRepository(applicationContext))

        ScreenCaptureState.setRunning(true)
        return START_STICKY
    }

    override fun onDestroy() {
        AutoTranslationEngine.stop()

        controller?.release()
        controller = null

        mediaProjection?.unregisterCallback(projectionCallback)
        mediaProjection?.stop()
        mediaProjection = null

        ScreenCaptureState.setRunning(false)
        super.onDestroy()
    }

    private fun stopSelfSafely() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(): Notification {
        val isPortuguese = Locale.getDefault().language == "pt"
        val contentText = if (isPortuguese) {
            "Detectando texto na tela para tradução"
        } else {
            "Detecting on-screen text for translation"
        }

        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("GameTranslatorAI")
            .setContentText(contentText)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createNotificationChannelIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return

        val isPortuguese = Locale.getDefault().language == "pt"
        val channelName = if (isPortuguese) "Tradução em tempo real" else "Real-time translation"

        val channel = NotificationChannel(CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_LOW)
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val ACTION_START = "com.gametranslatorai.app.capture.action.START"
        const val ACTION_STOP = "com.gametranslatorai.app.capture.action.STOP"
        const val EXTRA_RESULT_CODE = "com.gametranslatorai.app.capture.extra.RESULT_CODE"
        const val EXTRA_RESULT_DATA = "com.gametranslatorai.app.capture.extra.RESULT_DATA"

        private const val CHANNEL_ID = "screen_capture_channel"
        private const val NOTIFICATION_ID = 1001
    }
}

/**
 * Leitura de extra Parcelable compatível com todas as versões do minSdk
 * suportado: `getParcelableExtra(String)` é depreciado a partir do
 * Android 13 em favor da variante com [Class].
 */
private fun Intent.getParcelableExtraCompat(key: String): Intent? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        getParcelableExtra(key, Intent::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(key)
    }
}
