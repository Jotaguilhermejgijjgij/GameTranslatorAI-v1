package com.gametranslatorai.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.gametranslatorai.app.ui.localization.LocalAppStrings
import kotlinx.coroutines.delay

/**
 * Tela de carregamento/splash exibida ao abrir o app.
 * Apenas o nome do app e um pequeno atraso antes de ir para a Home.
 * Não faz nenhuma inicialização pesada ainda (isso será revisado quando
 * a camada de persistência/tema precisar carregar dados salvos).
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val strings = LocalAppStrings.current

    LaunchedEffect(Unit) {
        delay(1200)
        onFinished()
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = strings.appName,
            style = MaterialTheme.typography.headlineMedium
        )
    }
}
