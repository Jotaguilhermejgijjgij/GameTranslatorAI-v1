package com.gametranslatorai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.gametranslatorai.app.persistence.UserPreferencesRepository
import com.gametranslatorai.app.persistence.UserSettings
import com.gametranslatorai.app.ui.localization.LocalAppStrings
import com.gametranslatorai.app.ui.localization.stringsFor
import com.gametranslatorai.app.ui.navigation.GameTranslatorNavGraph
import com.gametranslatorai.app.ui.theme.GameTranslatorAITheme

/**
 * Activity única do aplicativo (arquitetura single-activity).
 * Toda a navegação entre telas (splash, home, configurações e futuras
 * telas) acontece dentro do grafo de navegação do Compose.
 *
 * Etapa 2: a Activity agora também é responsável por criar o
 * [UserPreferencesRepository] e observar as preferências salvas
 * (idioma do app, idioma de tradução), disponibilizando-as para toda a
 * árvore de telas via [CompositionLocalProvider].
 */
class MainActivity : ComponentActivity() {

    private val preferencesRepository by lazy {
        UserPreferencesRepository(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val userSettings by preferencesRepository.userSettings
                .collectAsState(initial = UserSettings())
            val strings = stringsFor(userSettings.appLanguage)

            CompositionLocalProvider(LocalAppStrings provides strings) {
                GameTranslatorAITheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        GameTranslatorNavGraph(
                            preferencesRepository = preferencesRepository,
                            userSettings = userSettings
                        )
                    }
                }
            }
        }
    }
}
