package com.gametranslatorai.app.translation

import com.gametranslatorai.app.ocr.DetectedText
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Estrutura de entrega dos textos detectados pelo OCR para a próxima
 * etapa do pipeline de tradução.
 *
 * Fluxo completo planejado:
 *   texto detectado pelo OCR (Etapa 3, aqui)
 *     -> IA identifica o idioma (Etapa 4)
 *     -> IA traduz para o idioma escolhido nas Configurações (Etapa 2)
 *     -> tradução aparece sobre o jogo (Etapa 9)
 *
 * Etapa 3: apenas repassa o texto bruto reconhecido pelo OCR, sem
 * identificar idioma nem traduzir. A Etapa 4 vai coletar [detectedText]
 * e implementar o restante do pipeline, sem precisar alterar esta classe
 * nem o serviço de captura.
 */
object DetectedTextPipeline {

    private val _detectedText = MutableSharedFlow<DetectedText>(
        replay = 0,
        extraBufferCapacity = 32
    )

    /** Fluxo de textos detectados, um evento por texto reconhecido pelo OCR. */
    val detectedText: SharedFlow<DetectedText> = _detectedText.asSharedFlow()

    /** Chamado pelo motor de captura/OCR sempre que um novo texto é reconhecido. */
    suspend fun submit(text: DetectedText) {
        _detectedText.emit(text)
    }
}
