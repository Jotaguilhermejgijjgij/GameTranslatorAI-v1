package com.gametranslatorai.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gametranslatorai.app.persistence.UserPreferencesRepository
import com.gametranslatorai.app.persistence.UserSettings
import com.gametranslatorai.app.ui.screens.HomeScreen
import com.gametranslatorai.app.ui.screens.SettingsScreen
import com.gametranslatorai.app.ui.screens.SplashScreen
import kotlinx.coroutines.launch

/** Nomes das rotas de navegação, centralizados para evitar strings soltas. */
object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val SETTINGS = "settings"
}

/**
 * Grafo de navegação principal do app: Splash -> Home -> Configurações.
 *
 * Etapa 2: a tela de Configurações recebe as preferências atuais do
 * usuário e uma forma de salvá-las através do [UserPreferencesRepository].
 */
@Composable
fun GameTranslatorNavGraph(
    preferencesRepository: UserPreferencesRepository,
    userSettings: UserSettings,
    navController: NavHostController = rememberNavController()
) {
    val coroutineScope = rememberCoroutineScope()

    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinished = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(onOpenSettings = { navController.navigate(Routes.SETTINGS) })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                userSettings = userSettings,
                onBack = { navController.popBackStack() },
                onAppLanguageSelected = { language ->
                    coroutineScope.launch { preferencesRepository.setAppLanguage(language) }
                },
                onTargetLanguageSelected = { language ->
                    coroutineScope.launch { preferencesRepository.setTargetLanguage(language) }
                }
            )
        }
    }
}
