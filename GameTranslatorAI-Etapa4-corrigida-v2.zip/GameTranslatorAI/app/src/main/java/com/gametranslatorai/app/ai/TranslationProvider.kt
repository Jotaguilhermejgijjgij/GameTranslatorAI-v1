package com.gametranslatorai.app.ai

import com.gametranslatorai.app.settings.model.TargetLanguage

/**
 * Resultado de uma tentativa de tradução por IA. Modelado como
 * [sealed class] para nunca precisar "inventar" um texto traduzido: cada
 * caminho possível (sucesso, texto não confiável, falha, provedor sem
 * credencial) é representado explicitamente.
 */
sealed class TranslationOutcome {

    /** Tradução concluída com sucesso pelo provedor de IA. */
    data class Success(
        val sourceText: String,
        val translatedText: String,
        val sourceLanguageCode: String?,
        val targetLanguage: TargetLanguage
    ) : TranslationOutcome()

    /**
     * O texto não pôde ser traduzido com confiança (ex.: OCR não trouxe
     * texto legível, idioma de origem não identificado, ou o texto já
     * está no idioma de destino). Não é um erro do provedor.
     */
    data class Unreliable(val reason: String) : TranslationOutcome()

    /** Falha real do provedor (ex.: não foi possível baixar/usar o modelo). */
    data class Failure(val reason: String) : TranslationOutcome()

    /**
     * O provedor exige uma credencial (ex.: chave de API de um serviço em
     * nuvem) que ainda não foi configurada. Não é usado pelo provedor
     * padrão desta etapa ([OnDeviceTranslationProvider], que não precisa
     * de credencial), mas fica pronto para futuros provedores em nuvem.
     */
    data class NotConfigured(val reason: String) : TranslationOutcome()
}

/**
 * Contrato para qualquer provedor de tradução por IA.
 *
 * Etapa 4: implementado por [OnDeviceTranslationProvider] (Google ML Kit,
 * roda inteiramente no aparelho, sem chave de API e sem custo).
 *
 * Um futuro provedor baseado em nuvem (ex.: um serviço de IA generativa
 * pago) pode implementar esta mesma interface sem exigir nenhuma mudança
 * em [com.gametranslatorai.app.translation.AutoTranslationEngine] nem nas
 * telas do app — basta trocar qual implementação é usada. Veja
 * `ai/README.md` para o passo a passo de como adicionar um provedor assim
 * com segurança (sem colocar a chave no código-fonte).
 */
interface TranslationProvider {
    suspend fun translate(text: String, targetLanguage: TargetLanguage): TranslationOutcome
}
