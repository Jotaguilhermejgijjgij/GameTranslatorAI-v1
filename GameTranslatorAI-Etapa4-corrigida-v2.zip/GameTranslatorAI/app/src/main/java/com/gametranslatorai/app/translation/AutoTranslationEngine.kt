package com.gametranslatorai.app.translation

import android.util.Log
import com.gametranslatorai.app.ai.OnDeviceTranslationProvider
import com.gametranslatorai.app.ai.TranslationOutcome
import com.gametranslatorai.app.ai.TranslationProvider
import com.gametranslatorai.app.ocr.DetectedText
import com.gametranslatorai.app.persistence.UserPreferencesRepository
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Orquestra o pipeline completo de tradução automática:
 *
 * ```
 * texto detectado pelo OCR (Etapa 3, via DetectedTextPipeline)
 *   -> identificação de idioma + tradução por IA (TranslationProvider)
 *   -> resultado em [translatedText], pronto para a etapa de apresentação
 * ```
 *
 * Roda apenas enquanto o modo de tradução estiver ativo: [start] é
 * chamado quando a captura de tela é iniciada e [stop] quando ela é
 * encerrada (ver [com.gametranslatorai.app.capture.ScreenCaptureService]).
 *
 * Usa sempre o idioma de destino salvo pelo usuário nas Configurações
 * (Etapa 2), lido em tempo real de [UserPreferencesRepository] — se o
 * usuário mudar o idioma de tradução, o próximo texto detectado já usa o
 * novo idioma, sem precisar reiniciar o app.
 *
 * Para evitar traduzir repetidamente o mesmo texto enquanto ele continuar
 * na tela, mantém um cache simples em memória (texto + idioma de destino
 * -> tradução). O cache é um [ConcurrentHashMap] comum; ao atingir o
 * limite de entradas, é simplesmente esvaziado (não precisa de uma
 * estrutura de LRU sofisticada para o que este pipeline exige).
 *
 * Nenhuma tradução é inventada: quando o provedor de IA não consegue
 * traduzir um texto com confiança, o texto é apenas descartado deste
 * pipeline (não é emitido nenhum resultado falso).
 */
object AutoTranslationEngine {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var pipelineJob: Job? = null

    private val provider: TranslationProvider = OnDeviceTranslationProvider()

    private val cache = ConcurrentHashMap<String, TranslatedText>()

    private val _translatedText = MutableSharedFlow<TranslatedText>(extraBufferCapacity = 32)

    /** Fluxo de textos já traduzidos, prontos para a etapa de apresentação. */
    val translatedText: SharedFlow<TranslatedText> = _translatedText.asSharedFlow()

    /** Começa a consumir [DetectedTextPipeline.detectedText] e traduzir cada texto novo. */
    fun start(preferencesRepository: UserPreferencesRepository) {
        if (pipelineJob != null) return

        cache.clear()
        pipelineJob = scope.launch {
            DetectedTextPipeline.detectedText.collect { detected ->
                processDetectedText(detected, preferencesRepository)
            }
        }
    }

    /** Para de traduzir novos textos. Os modelos de IA continuam carregados para a próxima vez. */
    fun stop() {
        pipelineJob?.cancel()
        pipelineJob = null
    }

    private suspend fun processDetectedText(
        detected: DetectedText,
        preferencesRepository: UserPreferencesRepository
    ) {
        val normalizedText = detected.text.trim()
        if (normalizedText.isEmpty()) return

        val targetLanguage = preferencesRepository.userSettings.first().targetLanguage
        val cacheKey = "${targetLanguage.storageKey}::$normalizedText"

        val cached = cache[cacheKey]
        if (cached != null) {
            // Mesmo texto, mesmo idioma de destino: reaproveita, não chama a IA de novo.
            _translatedText.emit(cached.copy(translatedAtMillis = System.currentTimeMillis()))
            return
        }

        when (val outcome = provider.translate(normalizedText, targetLanguage)) {
            is TranslationOutcome.Success -> {
                val result = TranslatedText(
                    originalText = outcome.sourceText,
                    translatedText = outcome.translatedText,
                    sourceLanguageCode = outcome.sourceLanguageCode,
                    targetLanguage = outcome.targetLanguage,
                    translatedAtMillis = System.currentTimeMillis()
                )
                if (cache.size >= CACHE_MAX_ENTRIES) {
                    cache.clear()
                }
                cache[cacheKey] = result
                _translatedText.emit(result)
            }
            is TranslationOutcome.Unreliable -> {
                Log.d(TAG, "Texto não traduzido (não confiável): ${outcome.reason}")
            }
            is TranslationOutcome.Failure -> {
                Log.w(TAG, "Falha ao traduzir texto: ${outcome.reason}")
            }
            is TranslationOutcome.NotConfigured -> {
                Log.w(TAG, "Provedor de tradução não configurado: ${outcome.reason}")
            }
        }
    }

    private const val TAG = "AutoTranslationEngine"
    private const val CACHE_MAX_ENTRIES = 50
}
