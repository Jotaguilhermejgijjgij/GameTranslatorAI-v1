# capture

Captura de tela usando a API oficial do Android (MediaProjection).

**Status (Etapa 3):** implementado e funcional.

- `ScreenCaptureService.kt` — serviço em primeiro plano que hospeda a
  sessão de `MediaProjection` já autorizada pelo usuário (a autorização é
  pedida pela tela inicial, via diálogo oficial do sistema).
- `ScreenCaptureController.kt` — cria o `VirtualDisplay`/`ImageReader`,
  captura quadros periodicamente e envia cada quadro ao OCR (`ocr/`).
- `FrameChangeDetector.kt` — evita reprocessar quadros repetidos (economia
  de bateria/CPU).
- `ScreenCaptureState.kt` — estado compartilhado (ativo/inativo) observado
  pela interface.

**Pendente:** frequência de captura ajustável pelo usuário (fixa em
1500ms por enquanto); overlay/caixa de tradução (Etapa 9).
