package com.gametranslatorai.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gametranslatorai.app.persistence.UserSettings
import com.gametranslatorai.app.settings.model.AppLanguage
import com.gametranslatorai.app.settings.model.TargetLanguage
import com.gametranslatorai.app.ui.localization.LocalAppStrings

/**
 * Tela de configurações.
 *
 * Etapa 2: primeira categoria real de configurações — Idioma. Permite
 * escolher o idioma da interface do GameTranslatorAI e o idioma para o
 * qual o conteúdo do jogo será traduzido. As duas escolhas são salvas
 * imediatamente através de [UserPreferencesRepository] (Jetpack DataStore)
 * e permanecem depois que o aplicativo é fechado e reaberto.
 *
 * As demais categorias (Aparência, Tradução, Inteligência Artificial,
 * Aplicativo, Sobre) serão adicionadas nas próximas etapas.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    userSettings: UserSettings,
    onBack: () -> Unit,
    onAppLanguageSelected: (AppLanguage) -> Unit,
    onTargetLanguageSelected: (TargetLanguage) -> Unit
) {
    val strings = LocalAppStrings.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings.settingsTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = strings.backContentDescription)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LanguageOptionSection(
                title = strings.appLanguageSectionTitle,
                description = strings.appLanguageSectionDescription,
                options = AppLanguage.entries,
                selectedOption = userSettings.appLanguage,
                optionLabel = { it.nativeName },
                onOptionSelected = onAppLanguageSelected
            )

            LanguageOptionSection(
                title = strings.targetLanguageSectionTitle,
                description = strings.targetLanguageSectionDescription,
                options = TargetLanguage.entries,
                selectedOption = userSettings.targetLanguage,
                optionLabel = { it.nativeName },
                onOptionSelected = onTargetLanguageSelected
            )
        }
    }
}

/**
 * Seção reutilizável de configuração com opções de escolha única (rádio),
 * usada aqui para os dois seletores de idioma da Etapa 2.
 */
@Composable
private fun <T> LanguageOptionSection(
    title: String,
    description: String,
    options: List<T>,
    selectedOption: T,
    optionLabel: (T) -> String,
    onOptionSelected: (T) -> Unit
) {
    Card(shape = MaterialTheme.shapes.medium) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = description, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))

            options.forEach { option ->
                val isSelected = option == selectedOption
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(selected = isSelected, onClick = { onOptionSelected(option) })
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = isSelected, onClick = { onOptionSelected(option) })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = optionLabel(option))
                }
            }
        }
    }
}
