# ocr

Reconhecimento de texto na tela (OCR).

**Status (Etapa 3):** implementado e funcional, usando o Google ML Kit
Text Recognition com o modelo embutido no app (offline, sem chave de
API). `TextRecognitionEngine.kt` recebe um bitmap e devolve as linhas de
texto realmente reconhecidas — nenhum texto é simulado.

`DetectedText.kt` é o modelo de dado devolvido para cada texto
reconhecido, consumido por `capture/ScreenCaptureController.kt` e
entregue a `translation/DetectedTextPipeline.kt`.

**Pendente:** identificação do idioma do texto detectado (Etapa 4).
