package com.gametranslatorai.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Tipografia base do GameTranslatorAI. Usa a fonte padrão do sistema
 * (leve, compatível com aparelhos simples). Tamanhos poderão ser
 * ajustados pela configuração "Tamanho do texto" em etapas futuras.
 */
val GameTranslatorTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 18.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp
    )
)
