package com.gametranslatorai.app.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Motor real de reconhecimento de texto (OCR), usando o Google ML Kit
 * Text Recognition com o modelo embutido no próprio app (não depende do
 * Google Play Services nem de internet — funciona totalmente offline e
 * sem qualquer chave de API).
 *
 * Etapa 3: apenas reconhece o texto visível em um bitmap e devolve as
 * linhas de texto encontradas, sem nenhuma tentativa de identificar
 * idioma ou traduzir — isso é responsabilidade da Etapa 4 (camada de IA).
 *
 * Nenhum texto é inventado ou simulado aqui: o retorno vem exclusivamente
 * do que o ML Kit efetivamente reconheceu na imagem recebida.
 */
class TextRecognitionEngine {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /** Reconhece o texto do [bitmap] e devolve as linhas não vazias e sem repetição. */
    suspend fun recognizeText(bitmap: Bitmap): List<String> {
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        return try {
            val result = awaitRecognition(inputImage)
            result.textBlocks
                .flatMap { block -> block.lines }
                .map { line -> line.text.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
        } catch (error: Exception) {
            // Falha pontual de reconhecimento (quadro corrompido, etc.):
            // não interrompe o laço de captura, apenas não gera resultado
            // para este quadro.
            emptyList()
        }
    }

    private suspend fun awaitRecognition(inputImage: InputImage) =
        suspendCancellableCoroutine { continuation ->
            recognizer.process(inputImage)
                .addOnSuccessListener { text -> continuation.resume(text) }
                .addOnFailureListener { error -> continuation.resumeWithException(error) }
        }

    /** Libera os recursos nativos do reconhecedor. Deve ser chamado ao encerrar a captura. */
    fun close() {
        recognizer.close()
    }
}
