package com.gametranslatorai.app.translation

import com.gametranslatorai.app.settings.model.TargetLanguage

/**
 * Um texto original já traduzido pela camada de IA, pronto para ser
 * apresentado ao usuário.
 *
 * A apresentação em si (substituir o texto no jogo, ou uma caixa/legenda
 * sobreposta) é responsabilidade de uma etapa futura — aqui só entregamos
 * o par (original, traduzido) já pronto e associado ao idioma de destino
 * usado.
 */
data class TranslatedText(
    val originalText: String,
    val translatedText: String,
    val sourceLanguageCode: String?,
    val targetLanguage: TargetLanguage,
    val translatedAtMillis: Long
)
