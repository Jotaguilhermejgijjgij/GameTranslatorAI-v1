# ai

Camada de tradução automática por IA.

**Status (Etapa 4):** implementado e funcional.

- `TranslationProvider.kt` — contrato (`interface`) que qualquer provedor
  de tradução por IA deve implementar, mais `TranslationOutcome`, um tipo
  que representa todos os resultados possíveis sem nunca precisar
  "inventar" uma tradução (sucesso, texto não confiável, falha, ou
  provedor sem credencial configurada).
- `OnDeviceTranslationProvider.kt` — implementação real e ativa, usando o
  Google ML Kit (identificação de idioma + tradução neural), rodando
  inteiramente no aparelho. **Não usa nenhuma chave de API e não tem
  custo.** Os modelos de idioma são baixados automaticamente na primeira
  vez que um par de idiomas é usado (exige internet só nesse momento) e
  depois disso funcionam 100% offline, sem enviar nenhum texto do usuário
  para servidor nenhum.

## Como adicionar um provedor em nuvem no futuro (com segurança)

Se um dia for necessário usar um serviço de IA em nuvem (ex.: para maior
qualidade de tradução com contexto), basta:

1. Criar uma nova classe que implemente `TranslationProvider`, por
   exemplo `CloudTranslationProvider`.
2. Ler a chave de API de um local seguro **fora do código-fonte** — por
   exemplo, de um campo gerado a partir de `local.properties` (arquivo que
   nunca é commitado) via `BuildConfig`, ou de um valor que o próprio
   usuário insere em uma tela de configurações e que fica salvo de forma
   criptografada no aparelho (`EncryptedSharedPreferences`). **Nunca**
   escrever a chave diretamente em um arquivo `.kt`.
3. Se a chave não estiver configurada, o provedor deve devolver
   `TranslationOutcome.NotConfigured` (já existe para isso) em vez de
   simular uma tradução.
4. Trocar qual implementação é usada em
   `translation/AutoTranslationEngine.kt` (hoje fixa em
   `OnDeviceTranslationProvider`) — nenhuma outra parte do app precisa
   mudar, pois tudo depende apenas da interface `TranslationProvider`.

Nenhuma chamada a serviço pago existe hoje neste projeto.
