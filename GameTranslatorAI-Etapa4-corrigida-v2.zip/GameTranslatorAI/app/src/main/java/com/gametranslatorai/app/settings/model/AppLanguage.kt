package com.gametranslatorai.app.settings.model

/**
 * Idioma da interface do próprio GameTranslatorAI (menus, botões, telas).
 *
 * Etapa 2: apenas Português (Brasil) e Inglês, conforme solicitado.
 * Novos idiomas de interface podem ser adicionados aqui no futuro.
 */
enum class AppLanguage(val storageKey: String, val nativeName: String) {
    PT_BR(storageKey = "pt-BR", nativeName = "Português (Brasil)"),
    EN(storageKey = "en", nativeName = "English");

    companion object {
        val DEFAULT = PT_BR

        fun fromStorageKey(key: String?): AppLanguage =
            entries.firstOrNull { it.storageKey == key } ?: DEFAULT
    }
}
