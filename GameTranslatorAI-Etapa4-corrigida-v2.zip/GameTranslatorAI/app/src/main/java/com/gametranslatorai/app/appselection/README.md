# appselection

Reservado para a função de seleção do aplicativo/jogo que o usuário
deseja traduzir (listagem de apps instalados via PackageManager, respeitando
as permissões disponíveis no Android).

Será implementado na Etapa 5.
