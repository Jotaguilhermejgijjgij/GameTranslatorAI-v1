package com.gametranslatorai.app.ocr

/**
 * Um texto reconhecido pelo OCR em um instante específico.
 *
 * É o formato de saída da Etapa 3 e de entrada da Etapa 4: a próxima
 * etapa (tradução por IA) vai consumir estes objetos através de
 * [com.gametranslatorai.app.translation.DetectedTextPipeline], identificar
 * o idioma do texto e traduzi-lo para o idioma escolhido pelo usuário
 * (Etapa 2).
 */
data class DetectedText(
    val text: String,
    val detectedAtMillis: Long
)
