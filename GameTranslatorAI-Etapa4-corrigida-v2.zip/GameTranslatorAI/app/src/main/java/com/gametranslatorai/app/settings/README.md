# settings

Modelos de domínio das preferências configuráveis pelo usuário.

**Status (Etapa 2):** `model/AppLanguage.kt` e `model/TargetLanguage.kt`
implementados e já usados de verdade pela tela de Configurações e pela
camada de persistência (`persistence/UserPreferencesRepository.kt`).

**Pendente (Etapa 3):** modelos para as demais categorias de
configuração (cor do tema, modo automático/manual, frequência de OCR,
provedor de IA, app selecionado) e uma tela de Configurações organizada
por categorias/seções expansíveis.
