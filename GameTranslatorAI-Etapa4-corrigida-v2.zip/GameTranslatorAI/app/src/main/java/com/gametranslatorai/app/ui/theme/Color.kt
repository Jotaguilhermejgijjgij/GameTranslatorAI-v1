package com.gametranslatorai.app.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Paleta base provisória usada apenas na Etapa 1.
 *
 * A Etapa 2 vai substituir/expandir isto pelo sistema completo de cores
 * selecionáveis pelo usuário (vermelho, laranja, amarelo, verde, azul,
 * roxo, marrom, branco e preto), com branco como padrão.
 */
val NeutralWhite = Color(0xFFFFFFFF)
val NeutralBlack = Color(0xFF1A1A1A)
val AccentDefault = Color(0xFF3A3A3A)
val SurfaceLight = Color(0xFFFAFAFA)
