package com.gametranslatorai.app.ui.localization

import androidx.compose.runtime.staticCompositionLocalOf
import com.gametranslatorai.app.settings.model.AppLanguage

/**
 * Textos da interface do GameTranslatorAI.
 *
 * Etapa 2: localização feita dentro do próprio app (não depende da troca
 * de idioma do sistema operacional), cobrindo as telas já existentes
 * (Splash, Home e Configurações).
 * Etapa 3: adicionados os textos do modo de tradução (captura de tela +
 * detecção automática de texto).
 * Etapa 4: adicionados os textos da lista de traduções automáticas.
 * Novas telas devem adicionar seus textos aqui, em ambos os idiomas, para
 * nunca misturar Português e Inglês quando apenas um estiver selecionado.
 */
data class AppStrings(
    val appName: String,
    val homeSubtitle: String,
    val settingsTitle: String,
    val settingsContentDescription: String,
    val backContentDescription: String,
    val appLanguageSectionTitle: String,
    val appLanguageSectionDescription: String,
    val targetLanguageSectionTitle: String,
    val targetLanguageSectionDescription: String,
    val translationModeExplanation: String,
    val startTranslationButtonLabel: String,
    val stopTranslationButtonLabel: String,
    val detectedTextSectionTitle: String,
    val detectedTextEmptyMessage: String,
    val translatedTextSectionTitle: String,
    val translatedTextEmptyMessage: String
)

private val StringsPtBr = AppStrings(
    appName = "GameTranslatorAI",
    homeSubtitle = "Em breve você poderá selecionar um jogo ou aplicativo para traduzir.",
    settingsTitle = "Configurações",
    settingsContentDescription = "Configurações",
    backContentDescription = "Voltar",
    appLanguageSectionTitle = "Idioma do aplicativo",
    appLanguageSectionDescription = "Idioma usado nos textos e menus do GameTranslatorAI.",
    targetLanguageSectionTitle = "Traduzir jogo para",
    targetLanguageSectionDescription = "Idioma para o qual o conteúdo do jogo será traduzido.",
    translationModeExplanation = "Ao iniciar, o Android vai pedir sua autorização para capturar a tela. Nenhuma captura acontece sem essa confirmação.",
    startTranslationButtonLabel = "Iniciar modo de tradução",
    stopTranslationButtonLabel = "Parar modo de tradução",
    detectedTextSectionTitle = "Textos detectados na tela",
    detectedTextEmptyMessage = "Nenhum texto detectado ainda. Inicie o modo de tradução para começar.",
    translatedTextSectionTitle = "Traduções automáticas",
    translatedTextEmptyMessage = "Nenhuma tradução ainda. Assim que um texto for detectado, a tradução aparece aqui."
)

private val StringsEn = AppStrings(
    appName = "GameTranslatorAI",
    homeSubtitle = "Soon you'll be able to select a game or app to translate.",
    settingsTitle = "Settings",
    settingsContentDescription = "Settings",
    backContentDescription = "Back",
    appLanguageSectionTitle = "App language",
    appLanguageSectionDescription = "Language used in GameTranslatorAI's texts and menus.",
    targetLanguageSectionTitle = "Translate game to",
    targetLanguageSectionDescription = "Language the game's content will be translated into.",
    translationModeExplanation = "When you start, Android will ask you to authorize screen capture. Nothing is captured without that confirmation.",
    startTranslationButtonLabel = "Start translation mode",
    stopTranslationButtonLabel = "Stop translation mode",
    detectedTextSectionTitle = "Text detected on screen",
    detectedTextEmptyMessage = "No text detected yet. Start translation mode to begin.",
    translatedTextSectionTitle = "Automatic translations",
    translatedTextEmptyMessage = "No translations yet. Once a text is detected, its translation appears here."
)

fun stringsFor(language: AppLanguage): AppStrings = when (language) {
    AppLanguage.PT_BR -> StringsPtBr
    AppLanguage.EN -> StringsEn
}

/** Disponibiliza [AppStrings] para toda a árvore de composables. */
val LocalAppStrings = staticCompositionLocalOf { StringsPtBr }
