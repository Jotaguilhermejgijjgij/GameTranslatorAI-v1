# translation

Motor de tradução: orquestra OCR -> identificação de idioma -> IA ->
resultado pronto para apresentação.

**Status (Etapa 3):** `DetectedTextPipeline.kt` — estrutura de entrega dos
textos detectados pelo OCR (implementado).

**Status (Etapa 4):** implementado e funcional.

- `AutoTranslationEngine.kt` — consome `DetectedTextPipeline.detectedText`,
  busca o idioma de destino salvo pelo usuário (Etapa 2, via
  `persistence/UserPreferencesRepository`), chama a camada de IA (`ai/`)
  para identificar o idioma de origem e traduzir, e expõe o resultado em
  `translatedText`. Liga e desliga junto com o modo de tradução
  (`capture/ScreenCaptureService`). Evita retraduzir o mesmo texto
  enquanto ele continuar na tela através de um cache em memória.
- `TranslatedText.kt` — modelo de um texto original + sua tradução, pronto
  para a etapa de apresentação.

**Pendente (etapa futura):** apresentação da tradução sobre o jogo (caixa
de legenda/overlay) e/ou substituição do texto original.
