package com.gametranslatorai.app.ui.screens

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.gametranslatorai.app.capture.ScreenCaptureService
import com.gametranslatorai.app.capture.ScreenCaptureState
import com.gametranslatorai.app.ocr.DetectedText
import com.gametranslatorai.app.translation.AutoTranslationEngine
import com.gametranslatorai.app.translation.DetectedTextPipeline
import com.gametranslatorai.app.translation.TranslatedText
import com.gametranslatorai.app.ui.localization.LocalAppStrings

private const val MAX_VISIBLE_DETECTIONS = 8
private const val MAX_VISIBLE_TRANSLATIONS = 8

/**
 * Tela inicial do app.
 *
 * Etapa 2: textos vêm de [LocalAppStrings], respeitando o idioma de
 * interface escolhido pelo usuário nas Configurações.
 *
 * Etapa 3: controle real do modo de tradução. Ao tocar em "Iniciar modo
 * de tradução", o app pede a autorização oficial do Android para captura
 * de tela (nenhuma captura acontece sem essa confirmação do usuário) e,
 * uma vez autorizado, um serviço em primeiro plano passa a capturar a
 * tela periodicamente e rodar OCR sobre cada quadro.
 *
 * Etapa 4: cada texto reconhecido pelo OCR é automaticamente traduzido
 * (identificação de idioma + tradução por IA on-device) para o idioma
 * escolhido nas Configurações. As traduções reais aparecem na seção
 * "Traduções automáticas" abaixo — nada aqui é simulado ou pré-definido.
 *
 * A substituição do texto original do jogo e a caixa de legenda/overlay
 * final ainda serão implementadas em uma etapa futura.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpenSettings: () -> Unit) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val isTranslationActive by ScreenCaptureState.isRunning.collectAsState()

    val detectedTexts = remember { mutableStateListOf<DetectedText>() }
    LaunchedEffect(Unit) {
        DetectedTextPipeline.detectedText.collect { detected ->
            detectedTexts.add(0, detected)
            while (detectedTexts.size > MAX_VISIBLE_DETECTIONS) {
                detectedTexts.removeAt(detectedTexts.lastIndex)
            }
        }
    }

    val translatedTexts = remember { mutableStateListOf<TranslatedText>() }
    LaunchedEffect(Unit) {
        AutoTranslationEngine.translatedText.collect { translated ->
            translatedTexts.add(0, translated)
            while (translatedTexts.size > MAX_VISIBLE_TRANSLATIONS) {
                translatedTexts.removeAt(translatedTexts.lastIndex)
            }
        }
    }

    // Pede a permissão de notificação (Android 13+) apenas para que a
    // notificação do serviço em primeiro plano fique visível; a captura
    // continua funcionando normalmente mesmo se essa permissão for negada.
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* resultado apenas informativo */ }

    // Diálogo oficial do Android que pede a autorização explícita do
    // usuário para capturar a tela. Sem essa confirmação, nada é capturado.
    val screenCaptureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { activityResult ->
        val data = activityResult.data
        if (activityResult.resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, activityResult.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
        }
    }

    fun requestStartTranslationMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        val projectionManager = ContextCompat.getSystemService(
            context,
            MediaProjectionManager::class.java
        )
        projectionManager?.let { manager ->
            screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
        }
    }

    fun stopTranslationMode() {
        val stopIntent = Intent(context, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        context.startService(stopIntent)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(strings.appName) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = strings.settingsContentDescription)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = strings.homeSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = strings.translationModeExplanation,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (isTranslationActive) stopTranslationMode() else requestStartTranslationMode()
                }
            ) {
                Text(
                    text = if (isTranslationActive) {
                        strings.stopTranslationButtonLabel
                    } else {
                        strings.startTranslationButtonLabel
                    }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = strings.translatedTextSectionTitle,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (translatedTexts.isEmpty()) {
                Text(
                    text = strings.translatedTextEmptyMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    translatedTexts.forEach { translated ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.medium
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = translated.originalText,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = translated.translatedText,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = strings.detectedTextSectionTitle,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (detectedTexts.isEmpty()) {
                Text(
                    text = strings.detectedTextEmptyMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    detectedTexts.forEach { detected ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.medium
                        ) {
                            Text(
                                text = detected.text,
                                modifier = Modifier.padding(12.dp),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
