# Regras do ProGuard/R8 do GameTranslatorAI.
# Etapa 1: minificação desativada (isMinifyEnabled = false), portanto
# este arquivo ainda não tem regras específicas.
# Quando o app crescer (OCR, IA, rede), regras de "keep" para bibliotecas
# de terceiros deverão ser adicionadas aqui.
