# capture

Captura de tela usando a API oficial do Android (MediaProjection).

**Status (Etapa 3):** implementado e funcional.

- `ScreenCaptureService.kt` — serviço em primeiro plano que hospeda a
  sessão de `MediaProjection` já autorizada pelo usuário (a autorização é
  pedida pela tela inicial, via diálogo oficial do sistema).
- `ScreenCaptureController.kt` — cria o `VirtualDisplay`/`ImageReader`,
  captura quadros periodicamente e envia cada quadro ao OCR (`ocr/`).
- `FrameChangeDetector.kt` — evita reprocessar quadros repetidos (economia
  de bateria/CPU).
- `ScreenCaptureState.kt` — estado compartilhado (ativo/inativo) observado
  pela interface.

**Status (Etapa 5 — otimização):** o fluxo captura → OCR → tradução não
mudou, mas ficou mais leve:

- A captura passou a rodar em resolução reduzida (no máximo 1280px no
  lado maior, em vez da resolução nativa do aparelho), reduzindo o custo
  de memória do `ImageReader`, da conversão para `Bitmap` e do tempo de
  OCR por quadro.
- `ScreenCaptureController` agora também deduplica o texto reconhecido
  entre um ciclo e o próximo (além da deduplicação por imagem que o
  `FrameChangeDetector` já fazia), evitando reenviar à Etapa 4 um texto
  que não mudou, mesmo quando o quadro muda por outro motivo (ex.:
  animação de fundo do jogo).
- `FrameChangeDetector` teve o limiar de sensibilidade aumentado (10 →
  16), tolerando mais ruído/variação de brilho antes de considerar que a
  tela "mudou" e acionar o OCR.
- Intervalo entre capturas aumentado de 1500ms para 2000ms, priorizando
  menor consumo de CPU/bateria.

**Pendente:** frequência de captura ajustável pelo usuário; overlay/caixa
de tradução (etapa futura).
