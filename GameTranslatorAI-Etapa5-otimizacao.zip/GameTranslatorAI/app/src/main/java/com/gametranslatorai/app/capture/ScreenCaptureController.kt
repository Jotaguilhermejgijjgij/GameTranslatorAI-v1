package com.gametranslatorai.app.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.gametranslatorai.app.ocr.DetectedText
import com.gametranslatorai.app.ocr.TextRecognitionEngine
import com.gametranslatorai.app.translation.DetectedTextPipeline
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Controla a sessão real de captura de tela, usando os mecanismos
 * oficiais do Android: [MediaProjection] + [VirtualDisplay] + [ImageReader].
 *
 * Em vez de processar todo quadro disponível (o que rodaria a uma
 * frequência muito alta e consumiria bateria/CPU desnecessariamente),
 * roda um laço periódico que captura o quadro mais recente a cada
 * [CAPTURE_INTERVAL_MS] milissegundos. Quadros iguais ao anterior são
 * descartados pelo [FrameChangeDetector] antes de chamar o OCR.
 *
 * Etapa 5 (otimização, sem mudar o fluxo captura -> OCR -> texto
 * detectado -> tradução da Etapa 4):
 * 1. A captura roda em uma resolução reduzida (no máximo
 *    [MAX_CAPTURE_DIMENSION] px no lado maior), em vez da resolução
 *    nativa do aparelho. Isso reduz proporcionalmente o custo de memória
 *    do [ImageReader], o custo de conversão para [Bitmap] e o tempo que o
 *    OCR leva para processar cada quadro — sem precisar de nenhuma
 *    biblioteca nova.
 * 2. Um segundo nível de deduplicação (além do [FrameChangeDetector], que
 *    atua na imagem) evita reenviar para a Etapa 4 um texto que já foi
 *    emitido no ciclo anterior e continua idêntico na tela — importante
 *    porque um jogo pode ter animações de fundo que mudam o quadro mesmo
 *    quando o texto em si não mudou.
 *
 * Nenhum texto é simulado: o [TextRecognitionEngine] só devolve o que
 * realmente reconheceu no quadro capturado, e cada texto novo é entregue
 * ao [DetectedTextPipeline] para a próxima etapa (tradução por IA).
 */
class ScreenCaptureController(
    private val context: Context,
    private val mediaProjection: MediaProjection
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var captureJob: Job? = null

    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null

    private val ocrEngine = TextRecognitionEngine()
    private val frameChangeDetector = FrameChangeDetector()

    private var frameWidth = 0
    private var frameHeight = 0

    /** Últimos textos emitidos para a Etapa 4, para não reenviar o que não mudou. */
    private var lastEmittedTexts: Set<String> = emptySet()

    fun start() {
        val metrics = context.resources.displayMetrics
        val nativeWidth = metrics.widthPixels.coerceAtLeast(1)
        val nativeHeight = metrics.heightPixels.coerceAtLeast(1)
        val scaleFactor = computeDownscaleFactor(nativeWidth, nativeHeight)

        frameWidth = (nativeWidth * scaleFactor).toInt().coerceAtLeast(1)
        frameHeight = (nativeHeight * scaleFactor).toInt().coerceAtLeast(1)
        // A densidade também precisa ser escalada pelo mesmo fator, senão
        // o sistema mostraria só um pedaço ampliado da tela em vez da
        // tela inteira reduzida.
        val scaledDensityDpi = (metrics.densityDpi * scaleFactor).toInt().coerceAtLeast(1)

        val thread = HandlerThread("GameTranslatorAI-ScreenCapture").also { it.start() }
        handlerThread = thread
        val handler = Handler(thread.looper)

        val reader = ImageReader.newInstance(frameWidth, frameHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "GameTranslatorAI-VirtualDisplay",
            frameWidth,
            frameHeight,
            scaledDensityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        captureJob = scope.launch {
            while (isActive) {
                captureAndRecognizeOnce()
                delay(CAPTURE_INTERVAL_MS)
            }
        }
    }

    /**
     * Calcula o fator de redução para que o lado maior da tela não passe
     * de [MAX_CAPTURE_DIMENSION] pixels. Em aparelhos cuja tela já é menor
     * que esse limite, devolve 1 (sem redução) para não piorar a
     * qualidade do OCR sem necessidade.
     */
    private fun computeDownscaleFactor(width: Int, height: Int): Float {
        val longestSide = maxOf(width, height)
        if (longestSide <= MAX_CAPTURE_DIMENSION) return 1f
        return MAX_CAPTURE_DIMENSION.toFloat() / longestSide.toFloat()
    }

    private suspend fun captureAndRecognizeOnce() {
        val reader = imageReader ?: return
        val image = try {
            reader.acquireLatestImage()
        } catch (error: Exception) {
            null
        } ?: return

        try {
            val bitmap = imageToBitmap(image, frameWidth, frameHeight)
            image.close()
            if (bitmap == null) return

            if (!frameChangeDetector.isNewFrame(bitmap)) {
                bitmap.recycle()
                return
            }

            val recognizedLines = ocrEngine.recognizeText(bitmap)
            bitmap.recycle()

            emitOnlyNewLines(recognizedLines)
        } catch (error: Exception) {
            Log.w(TAG, "Falha ao processar um quadro capturado", error)
            try {
                image.close()
            } catch (_: Exception) {
                // já fechada; nada a fazer
            }
        }
    }

    /**
     * Compara o texto reconhecido agora com o que já foi emitido no ciclo
     * anterior e só entrega à Etapa 4 o que é efetivamente novo. Evita
     * reprocessar/retraduzir a mesma frase quando ela continua na tela.
     */
    private suspend fun emitOnlyNewLines(recognizedLines: List<String>) {
        val currentTexts = recognizedLines.toSet()
        val newLines = recognizedLines.filter { it !in lastEmittedTexts }
        lastEmittedTexts = currentTexts

        if (newLines.isEmpty()) return

        val now = System.currentTimeMillis()
        newLines.forEach { line ->
            DetectedTextPipeline.submit(DetectedText(text = line, detectedAtMillis = now))
        }
    }

    /**
     * Converte o [Image] (formato RGBA_8888) devolvido pelo [ImageReader] em
     * um [Bitmap] utilizável, descartando o padding de linha que o Android
     * pode adicionar (rowStride != largura * pixelStride).
     */
    private fun imageToBitmap(image: Image, targetWidth: Int, targetHeight: Int): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * targetWidth

            val rawBitmap = Bitmap.createBitmap(
                targetWidth + rowPadding / pixelStride,
                targetHeight,
                Bitmap.Config.ARGB_8888
            )
            rawBitmap.copyPixelsFromBuffer(buffer)

            if (rowPadding == 0) {
                rawBitmap
            } else {
                val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, targetWidth, targetHeight)
                rawBitmap.recycle()
                cropped
            }
        } catch (error: Exception) {
            Log.w(TAG, "Falha ao converter quadro capturado em bitmap", error)
            null
        }
    }

    /** Libera todos os recursos nativos abertos por esta sessão de captura. */
    fun release() {
        captureJob?.cancel()
        captureJob = null

        virtualDisplay?.release()
        virtualDisplay = null

        imageReader?.close()
        imageReader = null

        handlerThread?.quitSafely()
        handlerThread = null

        lastEmittedTexts = emptySet()

        ocrEngine.close()
    }

    companion object {
        private const val TAG = "ScreenCaptureController"

        /**
         * Intervalo entre capturas. Aumentado de 1500ms para 2000ms na
         * Etapa 5 para reduzir consumo de CPU/bateria em aparelhos mais
         * fracos, já que a prioridade passou a ser leveza em vez de
         * latência mínima. Uma configuração ajustável pelo usuário fica
         * para uma etapa futura.
         */
        private const val CAPTURE_INTERVAL_MS = 2000L

        /**
         * Lado maior (em pixels) usado para a captura. Capturar na
         * resolução nativa do aparelho (muitas vezes 1080p/1440p ou mais)
         * é desnecessariamente pesado para OCR; 1280px no lado maior já é
         * suficiente para reconhecer texto de jogos com boa precisão, com
         * uma fração do custo de memória e processamento.
         */
        private const val MAX_CAPTURE_DIMENSION = 1280
    }
}
