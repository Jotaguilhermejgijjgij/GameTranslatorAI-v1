package com.gametranslatorai.app.capture

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * Detecta se o quadro atual da tela mudou o suficiente em relação ao
 * último quadro processado, para evitar rodar o OCR repetidamente sobre a
 * mesma imagem — economia de bateria e processamento, conforme exigido
 * pelo projeto (item de otimização do OCR).
 *
 * Implementação propositalmente simples e leve: reduz o quadro a uma
 * amostra pequena (16x16) em escala de cinza e compara com a amostra
 * anterior. Não usa nenhuma biblioteca externa nem processamento pesado.
 *
 * Etapa 5: limiar aumentado de 10 para 16, para tolerar pequenas
 * variações de brilho/compressão e animações de fundo sem relação com o
 * texto (comuns em jogos), evitando OCR desnecessário nesses casos.
 */
class FrameChangeDetector(private val threshold: Int = 16) {

    private var lastSignature: IntArray? = null

    /** Retorna true se o quadro deve ser processado pelo OCR (mudou o suficiente). */
    fun isNewFrame(bitmap: Bitmap): Boolean {
        val signature = computeSignature(bitmap)
        val previous = lastSignature
        lastSignature = signature
        return previous == null || !isSimilar(previous, signature)
    }

    private fun isSimilar(a: IntArray, b: IntArray): Boolean {
        if (a.size != b.size) return false
        var totalDifference = 0
        for (i in a.indices) {
            totalDifference += abs(a[i] - b[i])
        }
        return totalDifference < threshold * a.size
    }

    private fun computeSignature(bitmap: Bitmap): IntArray {
        val scaled = Bitmap.createScaledBitmap(bitmap, SAMPLE_GRID, SAMPLE_GRID, false)
        val signature = IntArray(SAMPLE_GRID * SAMPLE_GRID)
        var index = 0
        for (y in 0 until SAMPLE_GRID) {
            for (x in 0 until SAMPLE_GRID) {
                val pixel = scaled.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                signature[index] = (r + g + b) / 3
                index++
            }
        }
        scaled.recycle()
        return signature
    }

    companion object {
        private const val SAMPLE_GRID = 16
    }
}
