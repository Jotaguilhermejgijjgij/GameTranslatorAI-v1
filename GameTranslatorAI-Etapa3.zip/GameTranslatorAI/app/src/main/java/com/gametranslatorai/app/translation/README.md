# translation

Motor de tradução: vai orquestrar OCR -> identificação de idioma -> IA ->
exibição da tradução.

**Status (Etapa 3):** `DetectedTextPipeline.kt` implementado — é a
estrutura de entrega dos textos detectados pelo OCR para a próxima etapa,
como um fluxo (`SharedFlow<DetectedText>`) que qualquer parte do app pode
observar.

**Pendente (Etapa 4):** consumir `DetectedTextPipeline.detectedText`,
identificar o idioma de cada texto, traduzir para o idioma escolhido em
Configurações (`persistence/UserPreferencesRepository`) usando a camada de
IA (`ai/`, ainda não implementada) e preparar o resultado para a caixa de
tradução sobreposta (Etapa 9).
